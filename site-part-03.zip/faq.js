import { motion } from './motion/config.js';
const list = document.querySelector('.faq-list');
if (list) {
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const entries = [...list.querySelectorAll('details')].map(question => ({
    question,
    summary:question.querySelector('summary'),
    answer:question.querySelector('.faq-answer'),
    expanded:question.open,
    animation:null,
    fade:null,
    targetHeight:0
  }));

  function heightFor(entry,expanded) {
    const style = getComputedStyle(entry.question);
    const scale = entry.question.getBoundingClientRect().width / entry.question.offsetWidth || 1;
    const box = ['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth']
      .reduce((sum,key) => sum + parseFloat(style[key] || 0),0);
    return box + entry.summary.getBoundingClientRect().height / scale
      + (expanded ? entry.answer.getBoundingClientRect().height / scale : 0);
  }
  function settle(entry) {
    entry.animation?.cancel();
    entry.fade?.cancel();
    entry.animation = entry.fade = null;
    entry.question.open = entry.expanded;
    entry.question.style.height = '';
    entry.answer.inert = !entry.expanded;
    window.dispatchEvent(new Event('aeris:faq-settled'));
  }
  function expand(entry,expanded) {
    const {question,summary,answer} = entry;
    const scale = question.getBoundingClientRect().width / question.offsetWidth || 1;
    const startHeight = question.getBoundingClientRect().height / scale;
    const startOpacity = question.open ? Number(getComputedStyle(answer).opacity) : 0;
    entry.animation?.cancel();
    entry.fade?.cancel();
    entry.animation = entry.fade = null;
    entry.expanded = expanded;
    question.open = true;
    question.dataset.expanded = String(expanded);
    summary.setAttribute('aria-expanded',String(expanded));
    answer.inert = !expanded;
    const endHeight = heightFor(entry,expanded);
    entry.targetHeight = endHeight;
    if (reducedMotion.matches) {settle(entry);return;}

    question.style.height = endHeight+'px';
    const duration = expanded ? motion.faq.openDuration : motion.faq.closeDuration;
    const animation = question.animate([
      {height:startHeight+'px'},
      {height:endHeight+'px'}
    ],{duration,easing:motion.cssEase,fill:'both'});
    entry.animation = animation;
    entry.fade = answer.animate([
      {opacity:startOpacity,transform:expanded ? `translateY(${motion.faq.answerRise}px)` : getComputedStyle(answer).transform},
      {opacity:expanded ? 1 : 0,transform:'translateY(0px)'}
    ],{duration:motion.faq.answerDuration,delay:expanded ? motion.faq.answerDelay : 0,easing:motion.cssEase,fill:'both'});
    animation.finished.then(() => {
      if (entry.animation === animation) settle(entry);
    }).catch(() => {});
  }

  for (const entry of entries) {
    entry.question.dataset.expanded = String(entry.expanded);
    entry.summary.setAttribute('aria-expanded',String(entry.expanded));
    entry.answer.inert = !entry.expanded;
    entry.question.addEventListener('click',event => {
      // The surrounding row padding is part of the same hit target. Keep
      // answer paragraphs selectable and let any answer links work normally.
      if (event.target.closest('.faq-answer p, .faq-answer a, .faq-answer button')) return;
      event.preventDefault();
      const next = !entry.expanded;
      if (next) for (const other of entries) {
        if (other !== entry && other.expanded) expand(other,false);
      }
      expand(entry,next);
    });
  }
  list.classList.add('is-enhanced');

  // Retarget an in-flight reveal if wrapping changes during a resize/font load.
  const resize = new ResizeObserver(() => {
    for (const entry of entries) {
      if (entry.animation && Math.abs(heightFor(entry,entry.expanded)-entry.targetHeight)>.5) {
        expand(entry,entry.expanded);
      }
    }
  });
  for (const entry of entries) {resize.observe(entry.summary);resize.observe(entry.answer);}
  reducedMotion.addEventListener('change',() => {
    if (reducedMotion.matches) for (const entry of entries) settle(entry);
  });
}
