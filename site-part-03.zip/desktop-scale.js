const site = document.querySelector('.site');
let previousPhoneWidth, previousPhoneFamily;

// Each approved composition scales within its own range. Low landscape phones
// retain their separate layout rather than inheriting a tall tablet artboard.
function updateLayoutScale() {
  const width = Math.min(document.documentElement.clientWidth, 1920);
  const phoneLandscape = matchMedia('(max-width:1151px) and (max-height:500px) and (orientation:landscape)').matches;
  const phoneFamily = phoneLandscape ? 'landscape' : width < 768 ? 'portrait' : null;
  if (phoneFamily && width === previousPhoneWidth && phoneFamily === previousPhoneFamily) return;
  previousPhoneWidth = width; previousPhoneFamily = phoneFamily;
  const desktopScale = width / 1600;
  site.style.setProperty('--desktop-scale', String(desktopScale));
  // Fit one viewport. Tall desktop windows need a taller composition instead
  // of putting all surplus height above a width-sized, bottom-anchored photo.
  const heroHeight = Math.max(120, document.documentElement.clientHeight / desktopScale - 20);
  // Grow the same bottom-anchored composition as the viewport gets taller.
  // The former delayed interpolation left hundreds of empty pixels above it.
  const familyHeight = Math.max(660, Math.min(1080, heroHeight * .82));
  const familyGrowth = Math.max(0, familyHeight - 660);
  site.style.setProperty('--desktop-hero-height', heroHeight + 'px');
  site.style.setProperty('--desktop-hero-family-height', familyHeight + 'px');
  site.style.setProperty('--desktop-hero-photo-top', Math.max(98, heroHeight - familyHeight) + 'px');
  site.style.setProperty('--desktop-hero-title-offset', (21 - familyGrowth * .06) + 'px');
  site.style.setProperty('--desktop-hero-audience-top', (132 - familyGrowth * .14) + 'px');
  site.style.setProperty('--desktop-hero-stat-width', Math.max(112, 134 - Math.max(0, familyHeight - 880) * .12) + 'px');
  const tablet = matchMedia('(min-width:768px) and (max-width:1151px) and (min-height:501px)').matches;
  const wideTablet = tablet && matchMedia('(min-width:960px)').matches;
  const reference = wideTablet ? 1024 : 768;
  site.style.setProperty('--tablet-scale', tablet ? String(width / reference) : '1');
  const landscape = matchMedia('(max-width:1151px) and (max-height:500px) and (orientation:landscape)').matches;
  const portrait = !landscape && matchMedia('(max-width:767px)').matches;
  // Keep type steady between the smallest reference and the next device
  // composition rather than shrinking the whole page at a single pixel.
  const phoneReference = landscape ? Math.max(568, Math.min(width, 1024)) : Math.max(390, width);
  site.style.setProperty('--phone-scale', landscape || portrait ? String(width / phoneReference) : '1');
  site.style.setProperty('--phone-reference-width', phoneReference + 'px');
  site.dataset.scaleLayout = landscape ? (width < 740 ? 'phone-landscape-narrow' : 'phone-landscape-wide') :
    portrait ? (width < 600 ? 'phone-portrait' : 'phone-compact') : tablet ? (wideTablet ? 'tablet-wide' : 'tablet-narrow') :
    (matchMedia('(min-width:1152px)').matches ? 'desktop' : 'native');
  if (landscape || portrait) {
    const bodyStyle = getComputedStyle(document.body);
    const usableWidth = width - (Number.parseFloat(bodyStyle.paddingLeft) || 0) -
      (Number.parseFloat(bodyStyle.paddingRight) || 0);
    site.style.setProperty('--phone-scale', String(usableWidth / phoneReference));
  }
}

updateLayoutScale();
window.addEventListener('resize', updateLayoutScale);
