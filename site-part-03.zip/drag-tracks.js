document.querySelectorAll('.drag-track').forEach(track => {
  let gesture = null;
  let didDrag = false;

  function start(event) {
    if (event.button !== 0 || track.scrollWidth <= track.clientWidth) return;
    // Touching a card uses the browser's native horizontal/vertical pan.
    if (event.pointerType === 'touch') return;
    if (event.target.closest('a,button,input,select,textarea')) return;
    event.preventDefault();
    // A mouse gesture should not retain a keyboard-only outline on the track.
    if (track.contains(document.activeElement)) document.activeElement.blur();
    didDrag = false;
    const scale = track.getBoundingClientRect().width / track.offsetWidth || 1;
    gesture = {pointer:event.pointerId,x:event.clientX,scroll:track.scrollLeft,scale,lastX:event.clientX,lastTime:event.timeStamp,velocity:0};
    track.setPointerCapture(event.pointerId);
    track.classList.add('is-dragging');
  }
  function move(event) {
    if (!gesture || gesture.pointer !== event.pointerId) return;
    const distance = event.clientX - gesture.x;
    if (Math.abs(distance) > 3) didDrag = true;
    track.scrollLeft = gesture.scroll - distance / gesture.scale;
    const elapsed = event.timeStamp - gesture.lastTime;
    if (elapsed > 0) gesture.velocity = gesture.velocity * .25 + (gesture.lastX - event.clientX) / gesture.scale / elapsed * .75;
    gesture.lastX = event.clientX; gesture.lastTime = event.timeStamp;
  }
  function stop(event) {
    if (!gesture || gesture.pointer !== event.pointerId) return;
    const finished = gesture;
    gesture = null;
    track.classList.remove('is-dragging');
    if (track.hasPointerCapture(event.pointerId)) track.releasePointerCapture(event.pointerId);
    track.dispatchEvent(new CustomEvent('aeris:drag-end', { detail: { velocity: didDrag && event.timeStamp - finished.lastTime < 80 ? finished.velocity : 0, cancelled: event.type !== 'pointerup' } }));
  }
  track.addEventListener('pointerdown',start);
  track.addEventListener('pointermove',move);
  for (const name of ['pointerup','pointercancel','lostpointercapture']) track.addEventListener(name,stop);
  track.addEventListener('dragstart',event => event.preventDefault());
  track.addEventListener('click',event => {
    if (didDrag && event.detail !== 0) {event.preventDefault();event.stopPropagation();didDrag=false;}
  },true);

  function navigate(key) {
    const card = track.querySelector('article');
    const scale = track.getBoundingClientRect().width / track.offsetWidth || 1;
    const step = card.getBoundingClientRect().width / scale + parseFloat(getComputedStyle(track).columnGap);
    if (key === 'Home') track.scrollLeft = 0;
    else if (key === 'End') track.scrollLeft = track.scrollWidth;
    else track.scrollLeft += (key === 'ArrowLeft' ? -1 : 1) * step;
  }
  // Keyboard navigation remains available on the focusable gallery region.
  track.addEventListener('keydown',event => {
    if (event.altKey || event.ctrlKey || event.metaKey || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault();navigate(event.key);
  });

});
