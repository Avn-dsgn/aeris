import './desktop-scale.js?v=20261025-composition30';
import './technology.js?v=20261029-performance47';
import './drag-tracks.js?v=20261025-mobile28';

import './results.js?v=20261027-clear45';
import './faq.js?v=20261025-results32';
import './landscape.js?v=20261025-mobile28';
import './hero-layout.js?v=20261029-performance47';

document.querySelectorAll('.case-info .slide-arrows button').forEach(button => {
  button.addEventListener('mousedown', event => {
    if (event.button !== 0) return;
    event.preventDefault();
    button.focus({ preventScroll: true });
  });
});

const dialog=document.querySelector('#information-dialog');
const information={
  privacy:['Privacy notice','This is a design preview of the AERIS clinic website. No appointment form or analytics is connected, and this preview does not collect patient information. The clinic’s approved privacy notice will be added before launch.'],
  terms:['Terms of use','AERIS is presented here as a conceptual dental clinic. The page is a design prototype; clinic details, patient stories and treatment images are illustrative. Full terms will be supplied before a production launch.'],
  cookies:['Cookie settings','This preview uses no analytics or advertising cookies. The page’s interactions run in your browser without storing personal information.']
};
document.querySelectorAll('[data-legal]').forEach(button=>button.addEventListener('click',()=>{
  const [heading,copy]=information[button.dataset.legal];
  dialog.querySelector('h2').textContent=heading;dialog.querySelector('p').textContent=copy;dialog.showModal();
}));
document.querySelector('#price-list').addEventListener('click',()=>{
  dialog.querySelector('h2').textContent='Treatment fees';
  dialog.querySelector('p').textContent='The approved price list has not been supplied for this design preview. Your treatment estimate is explained after assessment. Contact the clinic to ask about appointment types and fees.';
  dialog.showModal();
});
dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
