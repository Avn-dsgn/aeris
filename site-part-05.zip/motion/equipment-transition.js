// Crossfade the real outgoing slide, with its already decoded photograph.
// No cloning, line splitting, layout measurement or nested text entrances on click.
export function equipmentTransition(stage, { duration, finishEntry }) {
  let outgoing, animation;
  const settle = () => {
    animation?.cancel(); animation = null;
    if (!outgoing) return;
    outgoing.hidden = true;
    outgoing.classList.remove('tech-transition-outgoing');
    outgoing.removeAttribute('aria-hidden'); outgoing.removeAttribute('inert');
    outgoing = null;
  };
  const before = () => { finishEntry(); settle(); };
  const changed = event => {
    const previous = event.detail.previous;
    previous.classList.add('tech-transition-outgoing');
    previous.setAttribute('aria-hidden', 'true'); previous.setAttribute('inert', '');
    previous.hidden = false; outgoing = previous;
    animation = previous.animate([{ opacity: 1 }, { opacity: 0 }], {
      duration, easing: 'cubic-bezier(.4,0,.2,1)', fill: 'forwards',
    });
    animation.onfinish = settle;
  };
  stage.addEventListener('aeris:technology-before-change', before);
  stage.addEventListener('aeris:technology-change', changed);
  return () => {
    stage.removeEventListener('aeris:technology-before-change', before);
    stage.removeEventListener('aeris:technology-change', changed);
    settle();
  };
}
