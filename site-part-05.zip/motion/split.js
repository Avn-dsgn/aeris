// div avoids the incumbent Hero's descendant-span positioning selectors.
export function splitHeadline(SplitText, element) {
  const type = element.dataset.split || 'lines';
  return SplitText.create(element, {
    type, tag: 'div', mask: type.includes('lines') ? 'lines' : type,
    linesClass: 'motion-line', aria: 'auto',
  });
}

export function splitWords(_SplitText, element) {
  // Word opacity does not need measured lines. Preserve native whitespace and
  // wrapping without SplitText forcing layout for every editorial statement.
  const original = [...element.childNodes], label = element.getAttribute('aria-label');
  const text = element.textContent, words = [], fragment = document.createDocumentFragment();
  for (const copy of text.match(/\s+|\S+/g) || []) {
    if (/^\s+$/.test(copy)) { fragment.append(document.createTextNode(copy)); continue; }
    const span = document.createElement('span'); span.className = 'motion-word';
    span.textContent = copy; span.setAttribute('aria-hidden', 'true');
    words.push(span); fragment.append(span);
  }
  element.setAttribute('aria-label', text); element.replaceChildren(fragment);
  return { words, revert() {
    element.replaceChildren(...original);
    if (label === null) element.removeAttribute('aria-label'); else element.setAttribute('aria-label', label);
  } };
}
