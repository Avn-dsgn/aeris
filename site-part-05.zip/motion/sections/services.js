import { motion } from '../config.js';
import { onceInView, cardEntrance } from '../utils.js';

export function servicesMotion(gsap, ScrollTrigger, conditions) {
  const track = document.querySelector('#services-track');
  const cards = [...track.querySelectorAll('.service-card')];
  // This layer only preserves the approved artwork placement. It never animates
  // independently: copy, background and illustration belong to one card entrance.
  const illustrations = cards.map(card => {
    const art = card.querySelector('.service-art');
    const inner = document.createElement('div');
    inner.className = 'service-art-motion';
    inner.append(...art.childNodes); art.append(inner);
    if (conditions.desktop && !conditions.reduced) {
      inner.style.setProperty('--art-rest-scale', motion.services.artScale);
      inner.style.setProperty('--art-rest-y', motion.services.artDown + 'px');
    }
    return { art, inner };
  });
  const stopEntry = onceInView(gsap, ScrollTrigger, track, () => {
    const viewport = document.documentElement.clientWidth;
    const visible = cards.filter(card => {
      const box = card.getBoundingClientRect();
      return box.right > 0 && box.left < viewport;
    });
    visible.forEach((card, index) => {
      const delay = conditions.reduced ? 0 : Math.min(index * motion.services.stagger, motion.services.maxDelay);
      cardEntrance(gsap, card, conditions, delay, motion.services.entrance);
    });
  }, { prepare: cards, start: conditions.reduced ? motion.cards.start : motion.cards.showcaseStart });
  return () => {
    stopEntry();
    illustrations.forEach(({ art, inner }) => { art.append(...inner.childNodes); inner.remove(); });
  };
}
