// div avoids the incumbent Hero's descendant-span positioning selectors.
export function splitHeadline(SplitText, element) {
  const type = element.dataset.split || 'lines';
  return SplitText.create(element, {
    type, tag: 'div', mask: type.includes('lines') ? 'lines' : type,
    linesClass: 'motion-line', aria: 'auto',
  });
}

export function splitWords(SplitText, element) {
  // Inline words preserve native wrapping AND the artboard's first-line indent.
  // Block line wrappers would reset that carefully authored editorial grid.
  return SplitText.create(element, { type: 'words', tag: 'span', wordsClass: 'motion-word', aria: 'auto' });
}
