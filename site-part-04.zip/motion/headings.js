import { motion } from './config.js';
import { onceInView, willChangeDuring, fadeUp } from './utils.js';

// Every short heading uses the Hero's masked-line vocabulary. The four long
// editorial statements retain their separately approved scroll-writing effect.
export function maskedHeading(gsap, SplitText, element, conditions, delay = 0) {
  let split, tween, destroyed = false;
  const target = element.querySelector('.motion-heading-copy') || element;
  if (conditions.reduced) {
    tween = gsap.from(target, { opacity: 0, duration: motion.duration.reduced, clearProps: 'opacity' });
  } else {
    split = SplitText.create(target, {
      type: 'lines', mask: 'lines', tag: 'div', linesClass: 'motion-line',
      autoSplit: true, aria: 'auto',
      onSplit(self) {
        tween = gsap.from(self.lines, {
          yPercent: motion.reveal.maskRise, opacity: 0,
          duration: motion.headline.duration, stagger: motion.headline.stagger,
          delay, ease: motion.ease,
          onComplete() {
            // Revert after the callback has returned its tween to SplitText.
            queueMicrotask(() => { if (!destroyed) split?.revert(); });
          },
        });
        return willChangeDuring(tween, self.lines);
      },
    });
  }
  return {
    finish() { tween?.progress(1); },
    destroy() { destroyed = true; tween?.kill(); split?.revert(); },
  };
}

export function sharedHeadings(gsap, ScrollTrigger, SplitText, conditions) {
  const cleanup = [];
  const owned = '#home,#services,#technology,#results,#process,#reviews,#doctors,#faq,#consultation,#contact';
  document.querySelectorAll('main h2,main h3,main h4,footer h2').forEach(element => {
    if ((element.closest(owned) && !element.classList.contains('section-label')) || element.closest('[data-editorial-motion]') || !element.textContent.trim()) return;
    // Labels are quiet; display headings use the same masked lines everywhere.
    if (element.classList.contains('section-label') || element.closest('footer')) {
      cleanup.push(onceInView(gsap, ScrollTrigger, element, () => {
        gsap.from(element, { opacity: 0, duration: conditions.reduced ? motion.duration.reduced : motion.duration.reveal, ease: motion.ease, clearProps: 'opacity' });
      }, { prepare: [element], start: motion.cards.start }));
    } else {
      let heading;
      cleanup.push(onceInView(gsap, ScrollTrigger, element, () => {
        heading = maskedHeading(gsap, SplitText, element, conditions);
        const description = element.nextElementSibling;
        if (description?.tagName === 'P' && !description.hasAttribute('data-reveal')) fadeUp(gsap, description, conditions, motion.stagger);
      }, { prepare: [element], start: motion.cards.start }));
      cleanup.push(() => heading?.destroy());
    }
  });
  return () => cleanup.reverse().forEach(stop => stop());
}
