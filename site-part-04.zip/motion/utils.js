import { motion } from './config.js';
export const root = document.documentElement;
export function debounce(callback, delay) {
  let timer;
  const debounced = () => { clearTimeout(timer); timer = setTimeout(callback, delay); };
  debounced.cancel = () => clearTimeout(timer);
  return debounced;
}
export function loadScript(path) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = new URL(path, import.meta.url).href;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`Motion library unavailable: ${path}`));
    document.head.append(script);
  });
}
export function restoreVisibility() {
  root.classList.remove('motion-pending');
  root.dataset.motionState = 'fallback';
  document.querySelectorAll('[data-motion-awaiting]').forEach(node => node.removeAttribute('data-motion-awaiting'));
}
export function willChangeDuring(tween, elements, properties = 'transform, opacity') {
  const start = tween.eventCallback('onStart');
  const complete = tween.eventCallback('onComplete');
  tween.eventCallback('onStart', () => { elements.forEach(el => { el.style.willChange = properties; }); start?.(); });
  tween.eventCallback('onComplete', () => { elements.forEach(el => { el.style.willChange = ''; }); complete?.(); });
  return tween;
}

const seen = new WeakSet();
export function markEntered(element) {
  seen.add(element); element.dataset.motionEntered = 'true';
}
export function onceInView(gsap, ScrollTrigger, element, build, options = {}) {
  if (seen.has(element)) return () => {};
  const prepared = options.prepare ? Array.from(options.prepare) : [];
  const markSeen = () => markEntered(element);
  // A deep link, late font load or breakpoint change must never hide content
  // that the visitor has already reached. Leave that content fully readable.
  if ((prepared.length || options.skipVisible) && element.getBoundingClientRect().top < window.innerHeight) {
    markSeen(); return () => {};
  }
  prepared.forEach(node => node.setAttribute('data-motion-awaiting', 'true'));
  let scope, trigger;
  const reveal = () => {
    if (seen.has(element)) return;
    markSeen();
    // Remove the gate and establish all from-states in this same task: no
    // intervening paint of the unanimated content is possible.
    prepared.forEach(node => node.removeAttribute('data-motion-awaiting'));
    scope = gsap.context(build, element);
  };
  const focus = () => {
    if (seen.has(element)) return;
    // Focus is an explicit request for content. Bypass an unplayed entrance;
    // forcing every nested from/startAt tween to its end can restore from-states.
    markSeen(); prepared.forEach(node => node.removeAttribute('data-motion-awaiting'));
    trigger?.kill();
  };
  if (prepared.length) element.addEventListener('focusin', focus);
  trigger = ScrollTrigger.create({ trigger: element, start: options.start || motion.reveal.start, once: true, onEnter: reveal });
  return () => {
    trigger.kill(); scope?.revert(); element.removeEventListener('focusin', focus);
    prepared.forEach(node => node.removeAttribute('data-motion-awaiting'));
  };
}

export function cardEntrance(gsap, element, conditions, delay = 0, overrides = {}) {
  const settings = { ...motion.cards, ease: 'power3.out', ...overrides };
  return willChangeDuring(gsap.from(element, {
    opacity: 0, ...(conditions.reduced ? {} : { y: conditions.desktop ? settings.rise : settings.compactRise }),
    duration: conditions.reduced ? motion.duration.reduced : settings.duration,
    delay: conditions.reduced ? 0 : delay, ease: settings.ease,
    clearProps: 'opacity,transform,willChange',
  }), [element]);
}

export function fadeUp(gsap, element, conditions, delay = 0) {
  const tween = gsap.from(element, {
    opacity: 0, ...(conditions.reduced ? {} : { y: conditions.desktop ? motion.distance.desktop : motion.distance.compact }),
    duration: conditions.reduced ? motion.duration.reduced : motion.duration.reveal, delay: conditions.reduced ? 0 : delay,
    ease: motion.ease, clearProps: 'opacity,transform,willChange',
  });
  return willChangeDuring(tween, [element]);
}
