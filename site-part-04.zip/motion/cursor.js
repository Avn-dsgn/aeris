import { motion } from './config.js';

export function dragFeedback(gsap, conditions) {
  const tracks = [...document.querySelectorAll('.drag-track')];
  const cleanups = [];
  tracks.forEach(track => {
    let momentum;
    const stop = () => momentum?.kill();
    const end = event => {
      if (conditions.reduced || event.detail.cancelled || !event.detail.velocity) return;
      const travel = Math.max(-track.clientWidth * motion.inertia.maximumTravel, Math.min(track.clientWidth * motion.inertia.maximumTravel, event.detail.velocity * motion.inertia.distance));
      momentum = gsap.to(track, { scrollLeft: Math.max(0, Math.min(track.scrollWidth - track.clientWidth, track.scrollLeft + travel)), duration: motion.inertia.duration, ease: 'power3.out' });
    };
    track.addEventListener('pointerdown', stop); track.addEventListener('keydown', stop); track.addEventListener('wheel', stop, { passive: true }); track.addEventListener('aeris:drag-end', end);
    cleanups.push(() => { stop(); track.removeEventListener('pointerdown', stop); track.removeEventListener('keydown', stop); track.removeEventListener('wheel', stop); track.removeEventListener('aeris:drag-end', end); });
  });
  if (!conditions.desktop || conditions.reduced) return () => cleanups.reverse().forEach(stop => stop());
  const zones = tracks;
  const label = document.querySelector('#drag-cursor-label').content.querySelector('span');
  const cursor = document.createElement('div');
  cursor.className = 'drag-badge motion-drag-cursor'; cursor.setAttribute('aria-hidden', 'true');
  cursor.innerHTML = label.outerHTML;
  document.body.append(cursor);
  gsap.set(cursor, { x: 0, y: 0, xPercent: -50, yPercent: -50, scale: 0 });
  const position = { x: 0, y: 0 };
  const xTo = gsap.quickTo(position, 'x', { duration: motion.cursor.followDuration, ease: 'power3.out' });
  const yTo = gsap.quickTo(position, 'y', { duration: motion.cursor.followDuration, ease: 'power3.out' });
  const setX = gsap.quickSetter(cursor, 'x', 'px'), setY = gsap.quickSetter(cursor, 'y', 'px');
  let pointerX = 0, pointerY = 0, stretch = 0, diameter = motion.cursor.sourceSize, ticking = false;
  let active = null;
  const tick = (_time, delta) => {
    setX(position.x); setY(position.y);
    const dx = pointerX - position.x, dy = pointerY - position.y;
    const lag = Math.hypot(dx, dy);
    const target = Math.min(motion.cursor.maxStretch, lag / diameter * .55);
    stretch += (target - stretch) * (1 - Math.exp(-Math.min(delta, 50) / motion.cursor.stretchResponse));
    if (Math.abs(stretch) < .0001) stretch = 0;
    if (lag > .5) cursor.style.setProperty('--cursor-angle', Math.atan2(dy, dx) + 'rad');
    cursor.style.setProperty('--cursor-sx', String(1 + stretch));
    cursor.style.setProperty('--cursor-sy', String(1 / (1 + stretch)));
  };
  const stopTicker = () => { gsap.ticker.remove(tick); ticking = false; };
  const control = target => target.closest('a,button,input,select,textarea,summary,[contenteditable="true"]');
  const hide = () => {
    active?.classList.remove('has-drag-cursor'); active = null;
    stopTicker();
    delete cursor.dataset.activeZone;
    gsap.to(cursor, { scale: 0, duration: motion.cursor.leaveDuration, ease: motion.ease, overwrite: 'auto' });
  };
  const move = (event, zone) => {
    const hit = zone.classList.contains('is-dragging') ? document.elementFromPoint(event.clientX, event.clientY) : event.target;
    // The whole track is a continuous drag surface. In a card gutter the
    // pointer hits the track itself; it must not dismiss the custom cursor.
    if (event.pointerType === 'touch' || !hit || !zone.contains(hit) || hit.closest('[data-motion-awaiting]') || control(hit)) { hide(); return; }
    if (active !== zone) {
      hide(); active = zone;
      const scale = zone.getBoundingClientRect().width / zone.offsetWidth;
      cursor.style.setProperty('--cursor-unit', String(scale));
      diameter = motion.cursor.sourceSize * scale;
      cursor.style.width = cursor.style.height = diameter + 'px';
      xTo.tween.pause(); yTo.tween.pause();
      position.x = event.clientX; position.y = event.clientY;
      setX(position.x); setY(position.y);
      stretch = 0; cursor.style.setProperty('--cursor-sx', '1'); cursor.style.setProperty('--cursor-sy', '1');
      zone.classList.add('has-drag-cursor'); cursor.dataset.activeZone = zone.id;
      gsap.to(cursor, { scale: 1, duration: motion.cursor.enterDuration, ease: motion.ease, overwrite: 'auto' });
    }
    pointerX = event.clientX; pointerY = event.clientY;
    xTo(event.clientX); yTo(event.clientY);
    if (!ticking) { gsap.ticker.add(tick); ticking = true; }
  };
  zones.forEach(zone => {
    const enter = event => move(event, zone);
    const down = event => { move(event, zone); if (active) gsap.to(cursor, { scale: motion.cursor.pressedScale, duration: motion.cursor.enterDuration, overwrite: 'auto' }); };
    const up = () => { if (active) gsap.to(cursor, { scale: 1, duration: motion.cursor.enterDuration, overwrite: 'auto' }); };
    const listeners = [['pointerenter', enter], ['pointermove', enter], ['pointerleave', hide], ['pointerdown', down], ['pointerup', up], ['pointercancel', hide], ['focusin', hide]];
    listeners.forEach(([name, fn]) => zone.addEventListener(name, fn));
    cleanups.push(() => { listeners.forEach(([name, fn]) => zone.removeEventListener(name, fn)); zone.classList.remove('has-drag-cursor'); });
  });
  window.addEventListener('scroll', hide, { passive: true }); window.addEventListener('blur', hide);
  cleanups.push(() => { stopTicker(); window.removeEventListener('scroll', hide); window.removeEventListener('blur', hide); xTo.tween.kill(); yTo.tween.kill(); gsap.killTweensOf(cursor); cursor.remove(); });
  return () => cleanups.reverse().forEach(stop => stop());
}
