import { motion } from './config.js';
import { onceInView, willChangeDuring } from './utils.js';
import { splitHeadline } from './split.js';

export function reveal(gsap, ScrollTrigger, SplitText, element, { reduced = false, desktop = false, scroll = true, delay = 0 } = {}) {
  let split, tween;
  const build = () => {
    const kind = element.dataset.reveal || 'up';
    const from = { opacity: 0 };
    let targets = element;
    if (!reduced) {
      if (kind === 'up') from.y = desktop ? motion.distance.desktop : motion.distance.compact;
      if (kind === 'clip') from.clipPath = motion.reveal.clip;
      if (kind === 'mask') {
        split = splitHeadline(SplitText, element);
        targets = split[element.dataset.split || 'lines'];
        from.yPercent = motion.reveal.maskRise;
      }
    }
    tween = gsap.from(targets, {
      ...from, duration: reduced ? motion.duration.reduced : motion.duration.reveal,
      ease: motion.ease, delay: Number(element.dataset.delay || delay),
      stagger: reduced ? 0 : Number(element.dataset.stagger || 0),
      clearProps: 'opacity,transform,clipPath,willChange',
    });
    willChangeDuring(tween, Array.isArray(targets) ? targets : [targets]);
  };
  const stop = scroll ? onceInView(gsap, ScrollTrigger, element, build, { prepare: [element], start: motion.cards.start }) : (build(), () => {});
  return { get tween() { return tween; }, destroy() { stop(); tween?.kill(); split?.revert(); gsap.set(element, { clearProps: 'opacity,transform,clipPath,willChange' }); } };
}
