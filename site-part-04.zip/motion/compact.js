import { circleOutline } from './circle-outline.js';
import { compactEditorial } from './compact-editorial.js';
import { markEntered } from './utils.js';

// Phones and tablets use native one-shot visibility events. No ScrollTrigger,
// heavy split text, scroll timelines or image zooms.
export function compactMotion({ reduced }, playIntro) {
  const pending = new Map(), entrances = new Map(), animations = new Set(), listeners = [];
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) if (entry.isIntersecting) show(entry.target);
  }, { rootMargin: '0px 0px -12% 0px', threshold: 0 });

  function animate(element, delay = 0, rise = 16) {
    const base = getComputedStyle(element);
    const opacity = base.opacity, translate = base.translate;
    const animation = element.animate([
      { opacity: 0, translate: reduced ? translate : `0px ${rise}px` },
      { opacity, translate },
    ], { duration: reduced ? 160 : 650, delay: reduced ? 0 : delay, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'backwards' });
    animations.add(animation);
    const release = () => { animations.delete(animation); animation.cancel(); };
    animation.onfinish = release;
    animation.oncancel = () => animations.delete(animation);
    return animation;
  }
  function show(target, immediate = false) {
    if (immediate) {
      entrances.get(target)?.forEach(animation => animation.cancel()); entrances.delete(target);
    }
    const item = pending.get(target);
    if (!item) return;
    pending.delete(target); observer.unobserve(target); markEntered(target);
    const visible = new Set(item.parts.filter(part => {
      const rect = part.getBoundingClientRect();
      return rect.right > 0 && rect.left < innerWidth;
    }));
    item.onEnter?.(!immediate);
    const group = [];
    item.parts.forEach((part, index) => {
      part.removeAttribute('data-motion-awaiting');
      if (!immediate && visible.has(part)) group.push(animate(part, Math.min(index * 50, 100), item.rise));
    });
    if (group.length) {
      entrances.set(target, group);
      Promise.allSettled(group.map(animation => animation.finished)).then(() => {
        if (entrances.get(target) === group) entrances.delete(target);
      });
    }
  }
  function prepare(target, parts = [target], rise = 16, onEnter) {
    if (!target) return;
    if (target.dataset.motionEntered === 'true' || target.getBoundingClientRect().top < innerHeight) {
      markEntered(target); onEnter?.(false); return;
    }
    parts.forEach(part => part.setAttribute('data-motion-awaiting', 'true'));
    pending.set(target, { parts, rise, onEnter }); observer.observe(target);
    const focus = () => show(target, true);
    target.addEventListener('focusin', focus);
    listeners.push(() => target.removeEventListener('focusin', focus));
  }

  // The Hero retains a quiet arrival for its copy; large bitmap layers stay put.
  const hero = document.querySelector('.hero');
  if (playIntro && hero.getBoundingClientRect().bottom > 0) {
    document.documentElement.dataset.motionIntro = 'playing';
    const intro = [...hero.querySelectorAll('.hero-title,.hero-audience,.hero-stats,.hero-action')]
      .map((part, index) => animate(part, index * 45, 10));
    Promise.allSettled(intro.map(animation => animation.finished)).then(() => {
      document.documentElement.dataset.motionIntro = 'complete';
      window.dispatchEvent(new Event('aeris:hero-settled'));
    });
  } else document.documentElement.dataset.motionIntro = 'complete';

  listeners.push(compactEditorial({ reduced }));
  document.querySelectorAll('[data-editorial-motion]').forEach(section => {
    prepare(section.querySelector('.editorial-description'));
  });
  document.querySelectorAll('.section-label,.process-top>div,.review-card,.faq-list details,.consultation-main,.consultation-aside,.footer-brand,.footer-top>div,.footer-bottom>div')
    .forEach(element => prepare(element));
  document.querySelectorAll('.process-grid>li').forEach(card => {
    const outline = circleOutline(card);
    const { path, length } = outline;
    const target = card.getBoundingClientRect();
    if (!reduced && card.dataset.motionEntered !== 'true' && target.top >= innerHeight) {
      path.style.strokeDasharray = String(length);
      path.style.strokeDashoffset = String(length);
    }
    prepare(card, [...card.querySelectorAll(':scope>span,h3,p')], 12, shouldAnimate => {
      if (reduced || !shouldAnimate) {
        path.style.strokeDasharray = path.style.strokeDashoffset = ''; return;
      }
      const draw = path.animate([{ strokeDashoffset:length }, { strokeDashoffset:0 }], {
        duration:1350, easing:'linear', fill:'both',
      });
      animations.add(draw);
      draw.onfinish = () => {
        path.style.strokeDasharray = path.style.strokeDashoffset = '';
        animations.delete(draw); draw.cancel();
      };
      draw.oncancel = () => animations.delete(draw);
    });
    listeners.push(() => outline.destroy());
  });
  for (const selector of ['#services-track', '#doctors-track']) {
    const track = document.querySelector(selector);
    prepare(track, [...track.querySelectorAll('article')]);
  }
  const stage = document.querySelector('.technology-stage');
  const comparison = document.querySelector('.case-layout');
  prepare(stage, [stage], 0);
  prepare(comparison);

  // Only explicit slide changes get a short opacity response. The native range
  // control remains immediate; no hint sweep or pointer smoothing is attached.
  const transitions = new Map();
  const transition = (key, elements) => {
    transitions.get(key)?.forEach(animation => animation.cancel());
    transitions.set(key, elements.map(element => {
      const animation = element.animate([{ opacity: 0 }, { opacity: 1 }], {
        duration: reduced ? 120 : 220, easing: 'ease-out',
      });
      animations.add(animation);
      animation.onfinish = () => { animations.delete(animation); animation.cancel(); };
      animation.oncancel = () => animations.delete(animation);
      return animation;
    }));
  };
  const technology = event => { show(stage, true); transition(stage, [event.detail.current]); };
  const results = () => { show(comparison, true); transition(comparison, [...comparison.querySelectorAll('.comparison-visual,.case-description')]); };
  stage.addEventListener('aeris:technology-change', technology);
  const resultsSection = document.querySelector('#results');
  resultsSection.addEventListener('aeris:case-change', results);

  return () => {
    observer.disconnect();
    pending.forEach(item => item.parts.forEach(part => part.removeAttribute('data-motion-awaiting')));
    pending.clear(); entrances.clear(); animations.forEach(animation => animation.cancel()); animations.clear();
    listeners.forEach(stop => stop());
    stage.removeEventListener('aeris:technology-change', technology);
    resultsSection.removeEventListener('aeris:case-change', results);
  };
}
