// Native scroll, one RAF and only visible statements. No reflowing line splitter
// or scroll engine is attached to the compact layout.
export function compactEditorial({ reduced }) {
  if (reduced) return () => {};
  const records = new Map(), active = new Set();
  let frame = 0;
  function render() {
    frame = 0;
    const height = document.documentElement.clientHeight;
    const updates = [...active].map(element => {
      const rect = element.getBoundingClientRect();
      return [element, Math.min(1, Math.max(0, (height * .9 - rect.top) / (height * .55 + rect.height * .6)))];
    });
    for (const [element, value] of updates) {
      const record = records.get(element);
      const progress = Math.max(record.progress, value);
      record.progress = progress;
      record.words.forEach((word, index) => {
        const local = Math.max(0, Math.min(1, progress * (record.words.length + 3) - index));
        const opacity = String(Math.round((.22 + .78 * local) * 100) / 100);
        if (word.style.opacity !== opacity) word.style.opacity = opacity;
      });
      if (progress === 1) {
        element.dataset.motionEntered = 'true'; active.delete(element); observer.unobserve(element);
      }
    }
  }
  const schedule = () => { if (!frame && active.size) frame = requestAnimationFrame(render); };
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) active.add(entry.target);
      else if (entry.boundingClientRect.bottom < 0) { active.add(entry.target); }
      else active.delete(entry.target);
    }
    schedule();
  });
  document.querySelectorAll('[data-scrub-text]').forEach(element => {
    if (element.dataset.motionEntered === 'true' || element.getBoundingClientRect().bottom < 0) return;
    const original = [...element.childNodes], label = element.getAttribute('aria-label');
    const text = element.textContent;
    const words = (text.match(/\S+\s*/g) || []).map(copy => {
      const span = document.createElement('span'); span.textContent = copy;
      span.setAttribute('aria-hidden', 'true'); span.style.opacity = '.22'; return span;
    });
    element.setAttribute('aria-label', text); element.replaceChildren(...words);
    records.set(element, { original, label, words, progress:0 }); observer.observe(element);
  });
  window.addEventListener('scroll', schedule, { passive:true });
  window.addEventListener('resize', schedule, { passive:true });
  return () => {
    cancelAnimationFrame(frame); observer.disconnect();
    window.removeEventListener('scroll', schedule); window.removeEventListener('resize', schedule);
    records.forEach(({ original, label }, element) => {
      element.replaceChildren(...original);
      if (label === null) element.removeAttribute('aria-label'); else element.setAttribute('aria-label', label);
    });
  };
}
