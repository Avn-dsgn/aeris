import { motion } from '../config.js';
import { splitHeadline } from '../split.js';

export function heroMotion(gsap, ScrollTrigger, SplitText, { desktop, reduced }, playIntro) {
  const hero = document.querySelector('.hero');
  const family = hero.querySelector('.family');
  const words = [...hero.querySelectorAll('.hero-title > span')];
  const audience = hero.querySelectorAll('.hero-audience > span');
  const stats = hero.querySelectorAll('.hero-stats > div');
  const statsWrap = hero.querySelector('.hero-stats');
  const action = hero.querySelector('.hero-action');
  const copy = action.querySelector('p');
  const cta = action.querySelector('.cta-button');
  const nav = [...hero.querySelectorAll('.brand,.navigation,.menu-toggle,.contact-pill')];
  const surfaces = hero.querySelectorAll('.hero-surface');
  const glow = hero.querySelector('.hero-glow');
  const parts = [...surfaces, glow, family, ...words, ...audience, statsWrap, ...stats, action, copy, cta, ...nav];
  let intro, splits = [], parallax;
  const finish = () => {
    splits.forEach(split => split.revert()); splits = [];
    parts.forEach(el => { el.style.willChange = ''; });
    document.documentElement.dataset.motionIntro = 'complete';
    window.dispatchEvent(new Event('aeris:hero-settled'));
  };
  function replay() {
    intro?.progress(1).kill();
    splits.forEach(split => split.revert()); splits = [];
    document.documentElement.dataset.motionIntro = 'playing';
    intro = gsap.timeline({ defaults: { ease: motion.ease }, onComplete: finish });
    if (reduced) {
      intro.from(parts, { opacity: 0, duration: motion.duration.reduced, clearProps: 'opacity' });
      return;
    }
    parts.forEach(el => { el.style.willChange = 'transform, opacity'; });
    splits = words.map(word => splitHeadline(SplitText, word));
    intro.fromTo(surfaces, { opacity: 0, scale: motion.hero.cardScale }, { opacity: 1, scale: 1, duration: motion.hero.cardDuration }, 0)
      .fromTo(glow, { opacity: 0 }, { opacity: motion.hero.glowOpacity, duration: motion.hero.glowDuration }, motion.hero.glowAt)
      .fromTo(family, {
        opacity: 0, '--intro-photo-y': desktop ? motion.hero.photoRise : motion.hero.compactPhotoRise,
      }, { opacity: 1, '--intro-photo-y': '0%', duration: motion.hero.photoDuration }, motion.hero.photoAt)
      .fromTo(splits.flatMap(split => split.lines), { yPercent: motion.reveal.maskRise }, { yPercent: 0, duration: motion.hero.titleDuration, stagger: motion.hero.titleStagger }, motion.hero.titleAt)
      .fromTo(audience, { opacity: 0, '--intro-copy-y': motion.hero.audienceRise }, { opacity: 1, '--intro-copy-y': '0px', duration: motion.hero.audienceDuration }, motion.hero.audienceAt)
      .fromTo(statsWrap, { opacity: 0 }, { opacity: 1, duration: motion.hero.detailDuration }, motion.hero.statsAt)
      .fromTo(stats, { opacity: 0, y: desktop ? motion.distance.desktop : motion.distance.compact }, { opacity: 1, y: 0, duration: motion.hero.detailDuration, stagger: motion.stagger }, motion.hero.statsAt)
      .fromTo(action, { opacity: 0 }, { opacity: 1, duration: motion.hero.detailDuration }, motion.hero.copyAt)
      .fromTo(copy, { opacity: 0, y: desktop ? motion.distance.desktop : motion.distance.compact }, { opacity: .8, y: 0, duration: motion.hero.detailDuration }, motion.hero.copyAt)
      .fromTo(cta, { opacity: 0, y: desktop ? motion.distance.desktop : motion.distance.compact }, { opacity: 1, y: 0, duration: motion.hero.detailDuration }, motion.hero.ctaAt)
      .fromTo(nav, { opacity: 0, '--intro-nav-y': motion.hero.navRise }, { opacity: 1, '--intro-nav-y': '0%', duration: motion.hero.navDuration }, motion.hero.navAt);
    intro.duration(motion.hero.duration);
    // The artboard owns placement. The photo entrance changes only opacity and
    // vertical offset; desktop centring is independent of the depth scale.
  }
  if (desktop && !reduced) {
    parallax = gsap.timeline({ scrollTrigger: { trigger: hero, start: 'top top', end: 'bottom top', scrub: motion.hero.scrollScrub, invalidateOnRefresh: true } })
      // A bottom-anchored scale lifts the heads without ever exposing a cut
      // under the people. Only the lettering drifts relative to that layer.
      .fromTo(family, { '--scroll-photo-scale': 1 }, { '--scroll-photo-scale': motion.hero.scrollPhotoScale, ease: 'none' }, 0)
      .to(words, { '--scroll-word-y': motion.hero.scrollTitleRise + 'px', ease: 'none' }, 0)
      .to(audience, { '--scroll-audience-y': motion.hero.scrollAudienceRise + 'px', ease: 'none' }, 0);
  }
  if (playIntro && hero.getBoundingClientRect().bottom > 0) replay();
  else document.documentElement.dataset.motionIntro = 'complete';
  const key = event => {
    if (event.key.toLowerCase() !== 'r' || event.ctrlKey || event.metaKey || event.altKey || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName) || event.target.isContentEditable) return;
    const box = hero.getBoundingClientRect();
    if (box.top >= -window.innerHeight / 2 && box.bottom > 0) replay();
  };
  document.addEventListener('keydown', key);
  return () => {
    document.removeEventListener('keydown', key);
    intro?.kill(); parallax?.scrollTrigger?.kill(); parallax?.kill();
    splits.forEach(split => split.revert());
    gsap.set(parts, { clearProps: 'opacity,scale,willChange' });
    [family, ...words, ...audience, ...nav].forEach(el => {
      ['--intro-photo-y','--scroll-photo-scale','--scroll-word-y','--scroll-audience-y','--intro-copy-y','--intro-nav-y'].forEach(name => el.style.removeProperty(name));
    });
  };
}
