import { motion } from '../config.js';
import { onceInView, willChangeDuring } from '../utils.js';
import { maskedHeading } from '../headings.js';

export function faqMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const list = document.querySelector('.faq-list');
  const cleanups = [], headings = [], rules = [];
  list.classList.add('has-motion-rules');
  list.querySelectorAll('details').forEach((item, index) => {
    const rule = document.createElement('span');
    rule.className = 'motion-faq-rule'; rule.setAttribute('aria-hidden', 'true');
    const summary = item.querySelector('summary');
    // Closed native details hide every sibling of summary. The rule belongs
    // inside summary so it remains visible and does not become answer content.
    summary.prepend(rule); rules.push(rule);
    let entry, heading;
    const finish = () => { entry?.progress(1); heading?.finish(); };
    summary.addEventListener('pointerdown', finish); summary.addEventListener('keydown', finish);
    cleanups.push(() => { summary.removeEventListener('pointerdown', finish); summary.removeEventListener('keydown', finish); });
    cleanups.push(onceInView(gsap, ScrollTrigger, item, () => {
      const delay = conditions.reduced ? 0 : Math.min(index * motion.faq.stagger, motion.faq.maxDelay);
      entry = gsap.timeline();
      entry.from(item, { opacity: 0, duration: conditions.reduced ? motion.duration.reduced : motion.cards.duration, ease: motion.ease, clearProps: 'opacity' }, 0);
      entry.from(rule, {
        ...(conditions.reduced ? { opacity: 0 } : { scaleX: 0 }),
        duration: conditions.reduced ? motion.duration.reduced : motion.faq.lineDuration,
        delay, ease: motion.ease, clearProps: 'opacity,transform',
      }, 0);
      heading = maskedHeading(gsap, SplitText, summary.querySelector('h3'), conditions, delay + motion.faq.questionAt);
      headings.push(heading);
      const details = [...summary.querySelectorAll(':scope>span:not(.motion-faq-rule),:scope>img')];
      willChangeDuring(entry.from(details, {
        opacity: 0, ...(conditions.reduced ? {} : { y: motion.faq.questionRise }),
        duration: conditions.reduced ? motion.duration.reduced : motion.duration.reveal,
        delay: conditions.reduced ? 0 : delay + motion.faq.questionAt,
        ease: motion.ease, clearProps: 'opacity,transform,willChange',
      }, 0), details);
    }, { prepare: [item], start: motion.cards.start }));
  });
  return () => { headings.forEach(h => h.destroy()); cleanups.reverse().forEach(stop => stop()); rules.forEach(rule => rule.remove()); list.classList.remove('has-motion-rules'); };
}
