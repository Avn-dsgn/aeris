import { motion } from '../config.js';
import { maskedHeading } from '../headings.js';
import { fadeUp, onceInView } from '../utils.js';

export function technologyMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const stage = document.querySelector('.technology-stage');
  const surface = stage.querySelector('.technology-fluid-surface');
  const slides = [...stage.querySelectorAll('.tech-slide')];
  let scope, headings = [], ghost, entryTween;
  const active = () => slides.find(slide => !slide.hidden);
  // onceInView also marks a skipped deep-link/focus/breakpoint entrance as seen.
  const hasEntered = () => stage.dataset.motionEntered === 'true';
  const settle = () => {
    headings.forEach(h => { h.finish(); h.destroy(); }); headings = [];
    scope?.revert(); scope = null;
    if (ghost) { gsap.killTweensOf(ghost); ghost.remove(); ghost = null; }
  };
  function animateSlide(slide, initial = false) {
    headings = [];
    scope = gsap.context(() => {
      const duration = conditions.reduced ? motion.duration.reduced : motion.technology.changeDuration;
      gsap.from(slide, { opacity: 0, duration, ease: motion.transitionEase, clearProps: 'opacity' });
      const photo = slide.querySelector('.tech-equipment');
      if (!conditions.reduced) gsap.from(photo, { scale: initial ? motion.technology.photoScale : motion.technology.slideScale, duration: initial ? motion.technology.enterDuration : duration, ease: motion.ease, clearProps: 'transform' });
      headings.push(maskedHeading(gsap, SplitText, slide.querySelector('.tech-title'), conditions, motion.technology.titleAt));
      slide.querySelectorAll('.tech-line').forEach((wire, index) => {
        if (!wire.getClientRects().length) return;
        const delay = motion.technology.wireAt + index * motion.technology.detailStagger;
        wire.querySelectorAll('[data-wire-path]').forEach(path => {
          const length = path.getTotalLength();
          if (!conditions.reduced) gsap.fromTo(path, { strokeDasharray: length, strokeDashoffset: length }, { strokeDashoffset: 0, duration: motion.technology.wireDuration, delay, ease: motion.ease, clearProps: 'strokeDasharray,strokeDashoffset' });
        });
        if (!conditions.reduced) gsap.from(wire.querySelectorAll('[data-wire-node]'), { scale: 0, opacity: 0, transformOrigin: '50% 50%', duration: motion.technology.nodeDuration, delay, stagger: motion.stagger, ease: motion.ease, clearProps: 'transform,transformOrigin,opacity' });
      });
      slide.querySelectorAll('.tech-callout').forEach((callout, index) => {
        if (!callout.getClientRects().length) return;
        headings.push(maskedHeading(gsap, SplitText, callout.querySelector('h4'), conditions, motion.technology.captionAt + index * motion.technology.detailStagger));
        fadeUp(gsap, callout.querySelector('p'), conditions, motion.technology.captionAt + motion.stagger + index * motion.technology.detailStagger);
      });
      const benefit = slide.querySelector('.tech-benefit');
      const compact = !conditions.desktop;
      const benefitAt = compact ? motion.technology.compactBenefitAt : motion.technology.benefitAt;
      fadeUp(gsap, benefit, conditions, benefitAt);
      headings.push(maskedHeading(gsap, SplitText, benefit.querySelector('h4'), conditions, benefitAt));
      gsap.from(benefit.querySelector('p'), { opacity: 0, duration: conditions.reduced ? motion.duration.reduced : motion.duration.reveal, delay: conditions.reduced ? 0 : benefitAt + motion.stagger, ease: motion.ease, clearProps: 'opacity' });
    }, slide);
  }
  const stopEntry = onceInView(gsap, ScrollTrigger, stage, () => {
    entryTween = gsap.from(surface, { opacity: 0, duration: conditions.reduced ? motion.duration.reduced : motion.duration.reveal, ease: motion.ease, clearProps: 'opacity' });
    animateSlide(active(), true);
  }, { prepare: [surface, ...slides], start: conditions.reduced ? motion.cards.start : motion.cards.showcaseStart });
  const before = event => {
    entryTween?.progress(1);
    settle();
    if (!hasEntered() || conditions.reduced) return;
    ghost = event.detail.previous.cloneNode(true);
    ghost.hidden = false; ghost.classList.add('tech-transition-ghost');
    ghost.setAttribute('aria-hidden', 'true'); ghost.setAttribute('inert', '');
    ghost.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));
    stage.append(ghost);
  };
  const changed = event => {
    if (!hasEntered()) return;
    animateSlide(event.detail.current);
    if (ghost) {
      const outgoing = ghost;
      gsap.to(outgoing, { opacity: 0, duration: motion.technology.changeDuration, ease: motion.transitionEase, onComplete: () => { outgoing.remove(); if (ghost === outgoing) ghost = null; } });
    }
  };
  const interrupt = event => {
    if (!event.target.closest('button,a')) return;
    entryTween?.progress(1);
  };
  stage.addEventListener('aeris:technology-before-change', before);
  stage.addEventListener('aeris:technology-change', changed);
  stage.addEventListener('pointerdown', interrupt);
  return () => {
    stage.removeEventListener('aeris:technology-before-change', before);
    stage.removeEventListener('aeris:technology-change', changed);
    stage.removeEventListener('pointerdown', interrupt);
    settle(); stopEntry();
  };
}
