import { motion } from '../config.js';
import { onceInView, cardEntrance } from '../utils.js';

export function doctorsMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const track = document.querySelector('#doctors-track');
  // Portraits already include the complete outer shape and badge notch. Move
  // that original asset with its card; zooming it behind a second alpha mask
  // clips the arm and exposes the source notch during the entrance.
  const cards = [...track.querySelectorAll('.doctor-card')];
  const stopEntry = onceInView(gsap, ScrollTrigger, track, () => {
    cards.forEach((card, index) => {
      const delay = conditions.reduced ? 0 : Math.min(index * motion.doctors.stagger, motion.doctors.maxDelay);
      cardEntrance(gsap, card, conditions, delay);
    });
  }, { prepare: cards, start: conditions.reduced ? motion.cards.start : motion.cards.showcaseStart });
  return () => {
    stopEntry();
  };
}
