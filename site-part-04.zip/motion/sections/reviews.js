import { motion } from '../config.js';
import { onceInView, cardEntrance } from '../utils.js';

export function reviewsMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const cleanups = [];
  document.querySelectorAll('.review-card').forEach((card, index) => {
    cleanups.push(onceInView(gsap, ScrollTrigger, card, () => {
      const delay = conditions.desktop ? index * motion.reviews.stagger : 0;
      cardEntrance(gsap, card, conditions, delay);
    }, { prepare: [card], start: conditions.reduced ? motion.cards.start : motion.cards.showcaseStart }));
  });
  return () => cleanups.reverse().forEach(stop => stop());
}
