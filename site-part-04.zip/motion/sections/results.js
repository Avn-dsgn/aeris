import { motion } from '../config.js';
import { onceInView } from '../utils.js';

const hinted = new WeakSet();
export function resultsMotion(gsap, ScrollTrigger, conditions) {
  const section = document.querySelector('#results');
  const comparison = section.querySelector('.comparison');
  const layout = section.querySelector('.case-layout');
  const range = comparison.querySelector('input');
  const visual = comparison.querySelector('.comparison-visual');
  const photos = [comparison.querySelector('.before-image'), comparison.querySelector('.after-layer img')];
  const copies = [...section.querySelectorAll('.case-description')];
  let scope, ghost, hint, interacted = false, revealTween;
  const model = { value: Number(range.value) };
  const follow = gsap.quickTo(model, 'value', { duration: motion.results.followDuration, ease: 'power3.out', onUpdate: () => comparison.style.setProperty('--split', model.value + '%') });
  const render = event => {
    if (conditions.reduced) return;
    event.preventDefault();
    if (event.detail.immediate) { follow.tween.pause(); model.value = event.detail.value; comparison.style.setProperty('--split', model.value + '%'); }
    else follow(event.detail.value);
  };
  const cancelHint = () => { interacted = true; hinted.add(comparison); if (comparison.dataset.motionHint === 'playing') comparison.dataset.motionHint = 'cancelled'; hint?.kill(); revealTween?.progress(1); if (ghost) { gsap.killTweensOf(ghost); ghost.remove(); ghost = null; } };
  const startHint = () => {
    const bounds = comparison.getBoundingClientRect();
    if (conditions.reduced || interacted || hinted.has(comparison) || bounds.bottom <= 0 || bounds.top >= innerHeight) return;
    hinted.add(comparison);
    comparison.dataset.motionHint = 'playing';
    const state = { value: Number(range.value) };
    hint = gsap.timeline({ onComplete: () => { comparison.dataset.motionHint = 'complete'; }, defaults: { duration: motion.results.hintDuration / 2, ease: motion.transitionEase, onUpdate: () => comparison.dispatchEvent(new CustomEvent('aeris:hint-split', { detail: state.value })) } });
    hint.to(state, { value: motion.results.hintTo }).to(state, { value: motion.results.hintFrom });
  };
  function animateCase(initial = false) {
    scope = gsap.context(() => {
      const duration = conditions.reduced ? motion.duration.reduced : (initial ? motion.results.wipeDuration : motion.results.changeDuration);
      revealTween = gsap.from(visual, {
        opacity: 0, ...(conditions.reduced ? {} : { clipPath: initial ? 'inset(0 100% 0 0 round 20px)' : 'inset(0 0 0 0 round 20px)' }),
        duration, ease: motion.ease, clearProps: 'opacity,clipPath', onComplete: initial ? startHint : undefined,
      });
      if (!conditions.reduced) gsap.from(photos, { scale: initial ? motion.results.photoScale : motion.results.caseScale, duration, ease: motion.ease, clearProps: 'transform' });
      // One opacity transition for both captions. Re-splitting every heading
      // during rapid case changes caused repeated masks, measurement and jumps.
      gsap.fromTo(copies, { opacity: 0 }, {
        opacity: 1, duration: conditions.reduced ? motion.duration.reduced : motion.results.copyDuration,
        ease: 'power2.out', clearProps: 'opacity',
      });
    }, section);
  }
  const settle = () => { scope?.revert(); scope = null; };
  const stopEntry = onceInView(gsap, ScrollTrigger, layout, () => animateCase(true), {
    prepare: [visual, ...copies], start: motion.cards.start,
  });
  const before = () => {
    cancelHint(); settle();
    if (conditions.reduced) return;
    const a = comparison.getBoundingClientRect(), b = layout.getBoundingClientRect();
    const scale = b.width / layout.offsetWidth;
    ghost = comparison.cloneNode(true); ghost.classList.add('motion-case-ghost');
    ghost.querySelectorAll('input,label,[id]').forEach(node => node.remove());
    ghost.removeAttribute('role'); ghost.setAttribute('aria-hidden', 'true'); ghost.setAttribute('inert', '');
    Object.assign(ghost.style, { left: (a.left - b.left) / scale + 'px', top: (a.top - b.top) / scale + 'px', width: comparison.offsetWidth + 'px', height: comparison.offsetHeight + 'px' });
    layout.append(ghost);
  };
  const changed = () => {
    animateCase();
    if (ghost) {
      const outgoing = ghost;
      gsap.to(outgoing, { opacity: 0, duration: motion.results.changeDuration, ease: motion.transitionEase, onComplete: () => { outgoing.remove(); if (ghost === outgoing) ghost = null; } });
    }
  };
  comparison.addEventListener('aeris:split-render', render);
  for (const name of ['pointerdown', 'keydown', 'input']) comparison.addEventListener(name, cancelHint, true);
  section.addEventListener('aeris:case-before-change', before); section.addEventListener('aeris:case-change', changed);
  return () => {
    comparison.removeEventListener('aeris:split-render', render);
    for (const name of ['pointerdown', 'keydown', 'input']) comparison.removeEventListener(name, cancelHint, true);
    section.removeEventListener('aeris:case-before-change', before); section.removeEventListener('aeris:case-change', changed);
    hint?.kill(); follow.tween.kill(); settle(); stopEntry();
    if (ghost) { gsap.killTweensOf(ghost); ghost.remove(); }
    comparison.style.setProperty('--split', range.value + '%');
  };
}
