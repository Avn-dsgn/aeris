import { motion } from '../config.js';
import { reveal } from '../reveal.js';
import { scrubText } from '../scrub-text.js';
import { markEntered } from '../utils.js';

export function editorialMotion(gsap, ScrollTrigger, SplitText, conditions, section) {
  const statement = section.querySelector('[data-scrub-text]');
  const description = section.querySelector('.editorial-description');
  const label = reveal(gsap, ScrollTrigger, SplitText, section.querySelector('.section-label'), conditions);
  if (conditions.reduced) {
    const body = description && reveal(gsap, ScrollTrigger, SplitText, description, conditions);
    const heading = reveal(gsap, ScrollTrigger, SplitText, statement, conditions);
    return () => [label, body, heading].forEach(animation => animation?.destroy());
  }
  const descriptionSeen = description?.dataset.motionEntered === 'true' || (description && description.getBoundingClientRect().top < innerHeight);
  if (descriptionSeen) markEntered(description);
  const detail = description && !descriptionSeen ? gsap.from(description, {
    opacity: 0, y: conditions.desktop ? motion.distance.desktop : motion.distance.compact,
    duration: motion.duration.reveal, ease: motion.ease, paused: true,
    onStart: () => { markEntered(description); description.style.willChange = 'transform, opacity'; },
    onComplete: () => { description.style.willChange = ''; },
  }) : null;
  const stopScrub = scrubText(gsap, ScrollTrigger, SplitText, statement, () => detail?.play());
  return () => {
    label.destroy(); detail?.kill(); stopScrub();
    if (description) gsap.set(description, { clearProps: 'opacity,transform,willChange' });
  };
}
