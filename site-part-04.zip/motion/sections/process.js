import { circleOutline } from '../circle-outline.js';
import { motion } from '../config.js';
import { maskedHeading } from '../headings.js';
import { onceInView, fadeUp } from '../utils.js';

export function processMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const grid = document.querySelector('.process-grid');
  const cards = [...grid.children], cleanup = [], headings = [], outlines = [];
  cards.forEach((card, index) => {
    const outline = circleOutline(card);
    const { path, length } = outline;
    outlines.push(path);
    const entryTarget = conditions.desktop ? grid : card;
    const alreadyVisible = entryTarget.dataset.motionEntered === 'true' || entryTarget.getBoundingClientRect().top < innerHeight;
    if (!conditions.reduced && !alreadyVisible) gsap.set(path, { strokeDasharray: `${length} ${length}`, strokeDashoffset: length });
    const number = card.querySelector(':scope>span'), title = card.querySelector('h3'), copy = card.querySelector('p');
    cleanup.push(onceInView(gsap, ScrollTrigger, card, () => {
      // Compact layouts stack these circles. Draw each when it is reached,
      // rather than completing unseen lower rows with the first circle.
      if (!conditions.desktop && !conditions.reduced) gsap.to(path, {
        strokeDashoffset: 0, duration: motion.process.drawDuration, ease: 'none',
        clearProps: 'strokeDasharray,strokeDashoffset',
      });
      const delay = conditions.desktop ? index * motion.process.stagger : 0;
      fadeUp(gsap, number, conditions, delay + motion.process.numberAt);
      headings.push(maskedHeading(gsap, SplitText, title, conditions, delay + motion.process.titleAt));
      fadeUp(gsap, copy, conditions, delay + motion.process.copyAt);
    }, { prepare: [number, title, copy], start: motion.cards.start }));
    cleanup.push(() => outline.destroy());
  });
  if (conditions.desktop) cleanup.push(onceInView(gsap, ScrollTrigger, grid, () => {
    if (conditions.reduced) return;
    gsap.to(outlines, {
      strokeDashoffset: 0, duration: motion.process.drawDuration, ease: 'none',
      clearProps: 'strokeDasharray,strokeDashoffset',
    });
  }, { start: motion.cards.start, skipVisible: true }));
  return () => { headings.forEach(h => h.destroy()); cleanup.reverse().forEach(stop => stop()); };
}
