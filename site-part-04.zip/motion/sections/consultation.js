import { motion } from '../config.js';
import { onceInView, cardEntrance } from '../utils.js';

export function consultationMotion(gsap, ScrollTrigger, conditions) {
  const panels = [...document.querySelectorAll('#consultation>.consultation-main,#consultation>.consultation-aside')];
  // The whole composition enters once. No separate photo, copy or button
  // animation can flash or run a second phase after the panel has arrived.
  const cleanups = panels.map((panel, index) => onceInView(gsap, ScrollTrigger, panel, () => {
    cardEntrance(gsap, panel, conditions, conditions.desktop ? index * motion.consultation.asideDelay : 0, motion.consultation.entrance);
  }, { prepare: [panel], start: motion.consultation.start }));
  return () => cleanups.reverse().forEach(stop => stop());
}
