import { motion } from '../config.js';
import { onceInView, fadeUp, willChangeDuring } from '../utils.js';

export function footerMotion(gsap, ScrollTrigger, conditions) {
  const footer = document.querySelector('.footer');
  const cleanups = [];
  const brand = footer.querySelector('.footer-brand');
  const letters = [...footer.querySelectorAll('.footer-brand svg path')];
  cleanups.push(onceInView(gsap, ScrollTrigger, brand, () => {
    willChangeDuring(gsap.from(letters, {
      opacity: 0, ...(conditions.reduced ? {} : { y: motion.footer.logoRise }),
      duration: conditions.reduced ? motion.duration.reduced : motion.footer.logoDuration,
      stagger: conditions.reduced ? 0 : motion.footer.letterStagger,
      ease: motion.ease, clearProps: 'opacity,transform,willChange',
    }), letters);
  }, { prepare: [brand], start: motion.cards.start }));
  footer.querySelectorAll('.footer-top>div,.footer-bottom>div').forEach((column, index) => {
    cleanups.push(onceInView(gsap, ScrollTrigger, column, () => {
      fadeUp(gsap, column, conditions, conditions.desktop ? Math.min(index * motion.footer.columnStagger, motion.footer.maxDelay) : 0);
    }, { prepare: [column], start: motion.cards.start }));
  });
  return () => cleanups.reverse().forEach(stop => stop());
}
