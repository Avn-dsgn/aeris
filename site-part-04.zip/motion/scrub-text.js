import { motion } from './config.js';
import { splitWords } from './split.js';

export function scrubText(gsap, ScrollTrigger, SplitText, element, onHalf) {
  const split = splitWords(SplitText, element);
  let revealed = false;
  const timeline = gsap.timeline({
    scrollTrigger: {
      trigger: element, start: motion.scrub.start, end: motion.scrub.end,
      scrub: motion.scrub.smooth,
      onUpdate(self) {
        if (!revealed && self.progress >= motion.scrub.descriptionAt) { revealed = true; onHalf?.(); }
      },
    },
  });
  timeline.fromTo(split.words, { opacity: motion.scrub.dim }, {
    opacity: 1, duration: motion.scrub.wordDuration, stagger: motion.scrub.stagger, ease: 'none',
  });
  // matchMedia's context may already have killed the ScrollTrigger before its
  // custom cleanup runs. Cleanup must be safe on either path.
  return () => { timeline.scrollTrigger?.kill(); timeline.kill(); split.revert(); };
}
