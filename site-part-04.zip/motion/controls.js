import { motion } from './config.js';

export function controlMotion() {
  const root = document.documentElement;
  root.style.setProperty('--motion-control-duration', motion.controls.arrowDuration + 's');
  root.style.setProperty('--motion-link-duration', motion.controls.linkDuration + 's');
  root.style.setProperty('--motion-css-ease', motion.cssEase);
  return () => ['--motion-control-duration','--motion-link-duration','--motion-css-ease'].forEach(name => root.style.removeProperty(name));
}
