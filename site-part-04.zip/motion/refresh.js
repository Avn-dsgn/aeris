import { motion } from './config.js';

// One desktop refresh owner. Never restore cached scroll coordinates while a
// native scroll/anchor journey is in flight; pixels loading alone need no refresh.
export function desktopRefresh(ScrollTrigger) {
  let dirty = false, timer, lastScroll = 0;
  let width = innerWidth, height = innerHeight;
  const root = document.documentElement;
  const attempt = () => {
    clearTimeout(timer);
    if (!dirty) return;
    if (root.hasAttribute('data-anchor-navigating') || performance.now() - lastScroll < 220 || ScrollTrigger.isScrolling()) {
      timer = setTimeout(attempt, 240); return;
    }
    dirty = false; ScrollTrigger.refresh();
  };
  const schedule = () => { dirty = true; clearTimeout(timer); timer = setTimeout(attempt, motion.refreshDebounce); };
  const scroll = () => { lastScroll = performance.now(); if (dirty) { clearTimeout(timer); timer = setTimeout(attempt, 240); } };
  const resize = () => {
    if (width === innerWidth && height === innerHeight) return;
    width = innerWidth; height = innerHeight; schedule();
  };
  const main = document.querySelector('main');
  let previous = { width: main.offsetWidth, height: main.offsetHeight };
  const observer = new ResizeObserver(entries => {
    const rect = entries[0].contentRect;
    if (Math.abs(rect.width - previous.width) < 1 && Math.abs(rect.height - previous.height) < 1) return;
    previous = rect; schedule();
  });
  observer.observe(main);
  window.addEventListener('resize', resize);
  window.addEventListener('scroll', scroll, { passive: true });
  window.addEventListener('scrollend', attempt);
  window.addEventListener('aeris:anchor-settled', attempt);
  return () => {
    clearTimeout(timer); observer.disconnect();
    window.removeEventListener('resize', resize); window.removeEventListener('scroll', scroll);
    window.removeEventListener('scrollend', attempt); window.removeEventListener('aeris:anchor-settled', attempt);
  };
}
