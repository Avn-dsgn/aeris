import { motion } from './config.js';

// Explicit links use the active scroll owner; compact/reduced mode stays native.
export function nativeNavigation({ reduced }, scrollEngine) {
  const root = document.documentElement;
  root.dataset.pageScroll = scrollEngine ? 'smooth' : 'native';
  let timer, destination;
  const complete = () => {
    clearTimeout(timer); destination = null;
    if (!root.hasAttribute('data-anchor-navigating')) return;
    delete root.dataset.anchorNavigating;
    window.dispatchEvent(new Event('aeris:anchor-settled'));
  };
  const ended = () => {
    if (!destination) return;
    const padding = parseFloat(getComputedStyle(root).scrollPaddingTop) || 0;
    const remaining = destination.getBoundingClientRect().top - padding;
    const atBottom = window.scrollY >= document.scrollingElement.scrollHeight - root.clientHeight - 2;
    if (Math.abs(remaining) < 2 || atBottom) complete();
  };
  const anchor = event => {
    const link = event.target.closest('a[href^="#"]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const target = document.getElementById(link.hash.slice(1));
    if (!target) return;
    event.preventDefault(); complete();
    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
    if (location.hash !== link.hash) history.pushState(null, '', link.hash);
    if (!reduced) {
      destination = target; root.dataset.anchorNavigating = 'true';
      // Fallback for browsers without scrollend; input always cancels the guard.
      timer = setTimeout(complete, motion.navigation.settleTimeout);
    }
    if (scrollEngine) scrollEngine.scrollTo(target, complete);
    else target.scrollIntoView({ behavior: reduced ? 'instant' : 'smooth', block: 'start' });
  };
  document.addEventListener('click', anchor);
  window.addEventListener('scrollend', ended);
  const cancelEvents = ['wheel', 'touchstart', 'pointerdown', 'keydown'];
  cancelEvents.forEach(name => window.addEventListener(name, complete, { passive: true }));
  return () => {
    complete(); document.removeEventListener('click', anchor); window.removeEventListener('scrollend', ended);
    cancelEvents.forEach(name => window.removeEventListener(name, complete)); delete root.dataset.pageScroll;
  };
}
