// A native circle has a fixed clockwise direction. Rotate its start to twelve.
export function circleOutline(card) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 100 100');
  svg.setAttribute('preserveAspectRatio', 'none');
  svg.setAttribute('aria-hidden', 'true');
  svg.classList.add('motion-circle-outline');
  const path = document.createElementNS(ns, 'circle');
  for (const [key, value] of Object.entries({ cx:50, cy:50, r:49.85, fill:'none', stroke:'#ebebeb', transform:'rotate(-90 50 50)' })) path.setAttribute(key, value);
  svg.append(path); card.prepend(svg); card.classList.add('motion-circle');
  const length = path.getTotalLength();
  const stroke = () => path.setAttribute('stroke-width', String(100 / Math.max(1, svg.clientWidth)));
  stroke();
  const resize = new ResizeObserver(stroke); resize.observe(svg);
  return { path, length, destroy() { resize.disconnect(); card.classList.remove('motion-circle'); svg.remove(); } };
}
