import { motion } from './config.js';
import { root, loadScript, restoreVisibility } from './utils.js';
import { nativeNavigation } from './navigation.js';
import { heroMotion } from './sections/hero.js';
import { editorialMotion } from './sections/approach.js';
import { reveal } from './reveal.js';
import { sharedHeadings } from './headings.js';
import { servicesMotion } from './sections/services.js';
import { technologyMotion } from './sections/technology.js';
import { resultsMotion } from './sections/results.js';
import { processMotion } from './sections/process.js';
import { reviewsMotion } from './sections/reviews.js';
import { doctorsMotion } from './sections/doctors.js';
import { faqMotion } from './sections/faq.js';
import { consultationMotion } from './sections/consultation.js';
import { footerMotion } from './sections/footer.js';
import { controlMotion } from './controls.js';
import { headerMotion } from './header.js';
import { dragFeedback } from './cursor.js?v=20261027-cursor46';
import { compactMotion } from './compact.js';
import { desktopRefresh } from './refresh.js';
import { smoothScroll } from './scroll.js';

let desktopLibraries;
function loadDesktopLibraries() {
  if (!desktopLibraries) desktopLibraries = (async () => {
    await loadScript('../vendor/gsap/gsap.min.js');
    await Promise.all([loadScript('../vendor/gsap/ScrollTrigger.min.js'), loadScript('../vendor/gsap/SplitText.min.js')]);
    const { gsap, ScrollTrigger, SplitText } = window;
    gsap.registerPlugin(ScrollTrigger, SplitText);
    // Refresh is owned by desktopRefresh, which waits for native scrolling to
    // settle. In compact mode these libraries are not requested at all.
    ScrollTrigger.config({ autoRefreshEvents: 'none', ignoreMobileResize: true });
    return { gsap, ScrollTrigger, SplitText };
  })();
  return desktopLibraries;
}

function fullMotion({ gsap, ScrollTrigger, SplitText }, conditions, playIntro) {
  const cleanups = [], scope = gsap.context(() => {});
  const dispose = () => { cleanups.reverse().forEach(stop => stop()); scope.revert(); };
  try {
    scope.add(() => {
      cleanups.push(heroMotion(gsap, ScrollTrigger, SplitText, conditions, playIntro));
      document.querySelectorAll('[data-editorial-motion]').forEach(section => {
        cleanups.push(editorialMotion(gsap, ScrollTrigger, SplitText, conditions, section));
      });
      document.querySelectorAll('[data-reveal="up"]').forEach(element => {
        if (element.closest('[data-editorial-motion],#reviews,#consultation')) return;
        const animation = reveal(gsap, ScrollTrigger, SplitText, element, conditions);
        cleanups.push(() => animation.destroy());
      });
      cleanups.push(sharedHeadings(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(servicesMotion(gsap, ScrollTrigger, conditions));
      cleanups.push(technologyMotion(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(resultsMotion(gsap, ScrollTrigger, conditions));
      cleanups.push(processMotion(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(reviewsMotion(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(doctorsMotion(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(faqMotion(gsap, ScrollTrigger, SplitText, conditions));
      cleanups.push(consultationMotion(gsap, ScrollTrigger, conditions));
      cleanups.push(footerMotion(gsap, ScrollTrigger, conditions));
      cleanups.push(headerMotion(gsap, conditions));
      cleanups.push(dragFeedback(gsap, conditions));
      ScrollTrigger.refresh();
      cleanups.push(desktopRefresh(ScrollTrigger));
    });
    return dispose;
  } catch (error) { dispose(); throw error; }
}

async function boot() {
  await document.fonts.ready;
  await document.querySelector('.family').decode().catch(() => {});
  if (location.hash) document.getElementById(location.hash.slice(1))?.scrollIntoView({ block: 'start', behavior: 'instant' });
  let played = !root.classList.contains('motion-pending') || window.scrollY > 24;
  let generation = 0, dispose = () => {};
  const desktop = matchMedia(motion.media.desktop), reduced = matchMedia(motion.media.reduce);
  root.style.setProperty('--hero-glow-opacity', String(motion.hero.glowOpacity));
  if (new URLSearchParams(location.search).has('rec')) root.classList.add('motion-recording');
  const update = async () => {
    const revision = ++generation;
    dispose(); dispose = () => {};
    const conditions = { desktop: desktop.matches, reduced: reduced.matches };
    root.dataset.motionState = 'loading';
    try {
      const libraries = conditions.desktop ? await loadDesktopLibraries() : null;
      if (revision !== generation) return;
      let scrollEngine;
      if (conditions.desktop && !conditions.reduced) {
        const { default: Lenis } = await import('../vendor/lenis/lenis.js');
        if (revision !== generation) return;
        scrollEngine = smoothScroll(Lenis, libraries.gsap, libraries.ScrollTrigger);
      }
      root.classList.add('motion-enabled'); root.classList.remove('motion-pending');
      const cleanups = [];
      try {
        if (scrollEngine) cleanups.push(() => scrollEngine.destroy());
        cleanups.push(conditions.desktop ? fullMotion(libraries, conditions, !played) : compactMotion(conditions, !played));
        played = true;
        cleanups.push(controlMotion()); cleanups.push(nativeNavigation(conditions, scrollEngine));
      } catch (error) { cleanups.reverse().forEach(stop => stop()); throw error; }
      dispose = () => cleanups.reverse().forEach(stop => stop());
      root.dataset.motionProfile = conditions.desktop ? 'full' : 'compact';
      root.dataset.motionState = conditions.reduced ? 'reduced' : 'ready';
    } catch (error) {
      if (revision !== generation) return;
      restoreVisibility(); console.warn('AERIS motion: static fallback', error);
    }
  };
  desktop.addEventListener('change', update); reduced.addEventListener('change', update);
  await update();
  window.addEventListener('pagehide', event => {
    if (event.persisted) return;
    generation++; dispose();
    desktop.removeEventListener('change', update); reduced.removeEventListener('change', update);
  });
}

boot().catch(error => { restoreVisibility(); console.warn('AERIS motion unavailable; static page preserved.', error); });
