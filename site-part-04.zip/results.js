const results = document.querySelector('#results');
const comparison = results.querySelector('.comparison');
const before = comparison.querySelector('.before-image');
const after = comparison.querySelector('.after-layer img');
const divider = comparison.querySelector('.comparison-divider > img');
const handle = comparison.querySelector('.comparison-handle img');
const range = comparison.querySelector('input[type="range"]');
const copyBlocks = [...results.querySelectorAll('.case-info > .case-description')];
const status = results.querySelector('.case-status');
const asset = name => `assets/sliders/${name}`;

const cases = [
  {
    key:'veneers', title:copyBlocks[0].querySelector('h3').textContent,
    description:copyBlocks[0].querySelector('p').textContent,
    concern:copyBlocks[1].querySelector('h3').textContent,
    detail:copyBlocks[1].querySelector('p').textContent,
    before:before.getAttribute('src'), after:after.getAttribute('src'),
    beforeAlt:before.alt, afterAlt:after.alt,
    divider:divider.getAttribute('src'), handle:asset('results-orthodontics-frame173.svg')
  },
  {
    key:'orthodontics',title:'Orthodontic treatment',
    description:'The front teeth were aligned while retaining their natural shape and shade. The finished smile shows a more even arrangement of the teeth.',
    concern:'Crowding & uneven alignment',
    detail:'The front teeth overlapped and sat at different angles. Treatment focused on their position and alignment within the smile.',
    before:'assets/results/clear-v5/orthodontics-before.webp',after:'assets/results/clear-v5/orthodontics-after.webp',
    beforeAlt:'Before orthodontic treatment: crowded and unevenly positioned front teeth',
    afterAlt:'After orthodontic treatment: the same smile with more evenly aligned front teeth',
    divider:asset('results-orthodontics-line9.svg'),handle:asset('results-orthodontics-frame173.svg')
  },
  {
    key:'implant',title:'Dental implant',
    description:'An implant-supported crown replaced the missing tooth. Its contour and shade were chosen to sit naturally alongside the neighbouring teeth.',
    concern:'A missing tooth in the smile',
    detail:'A gap interrupted the upper row of teeth. The restoration fills this space while keeping the individual character of the surrounding smile.',
    before:'assets/results/clear-v5/implant-before.webp',after:'assets/results/clear-v5/implant-after.webp',
    beforeAlt:'Before implant restoration: a missing upper tooth in a man’s smile',
    afterAlt:'After implant restoration: the same smile with the missing tooth replaced',
    divider:asset('results-implant-line9.svg'),handle:asset('results-implant-frame173.svg')
  },
  {
    key:'restoration',title:'Tooth-coloured restoration',
    description:'A tooth-coloured filling restored the damaged area of the molar. The surface was shaped to follow the natural contours of the chewing surface.',
    concern:'Decay & a damaged chewing surface',
    detail:'The molar had a visible cavity and a broken area on its chewing surface. The restoration rebuilds the missing tooth structure.',
    before:'assets/optimized/results-restoration-frame86.webp',after:'assets/optimized/results-restoration-frame87.webp',
    beforeAlt:'Before restoration: a molar with a damaged chewing surface and a visible cavity',
    afterAlt:'After restoration: the same molar with a tooth-coloured filling',
    divider:asset('results-restoration-line9.svg'),handle:asset('results-restoration-frame173.svg')
  }
];

// All imported backgrounds below the final opaque image in Figma are occluded.
// Use the final visible before/after layer at its original full-frame crop.
const imageSizes = '(min-width:760px) and (max-width:1151px) and (max-height:500px) and (orientation:landscape) calc(60vw - 24px), (max-width:1151px) calc(100vw - 20px), (min-width:1920px) 990px, 52vw';
const imageSet = url => {
  const stem = url.replace(/\.webp$/, '');
  return `${stem}-800.webp 800w, ${stem}-1200.webp 1200w, ${url} 1672w`;
};
const ready = new Map();
function loadImage(url) {
  if (ready.has(url)) return ready.get(url);
  const image = new Image();
  image.decoding = 'async';
  image.sizes = imageSizes;
  image.srcset = imageSet(url);
  image.src = url;
  const task = image.decode().catch(error => {ready.delete(url);throw error;});
  ready.set(url,task);
  return task;
}
const loadCase = item => Promise.all([loadImage(item.before),loadImage(item.after)]);
function warmNextCase(index) {
  const connection = navigator.connection;
  if (connection?.saveData || ['slow-2g','2g'].includes(connection?.effectiveType)) return;
  loadCase(cases[(index+1)%cases.length]).catch(() => {});
}
function applyImage(target,url,alt) {
  target.sizes = imageSizes;
  target.srcset = imageSet(url);
  target.src = url;
  target.alt = alt;
}
let current = 0;
let requested = 0;
let request = 0;

// Keep the hero's network path clear. Warm only the next case when Results
// approaches the viewport, rather than requesting every photograph on startup.
const observer = new IntersectionObserver(entries => {
  if (!entries.some(entry => entry.isIntersecting)) return;
  observer.disconnect();
  loadCase(cases[current]).then(() => warmNextCase(current)).catch(() => {});
},{rootMargin:'400px 0px'});
observer.observe(comparison);

function setSplit(value, immediate = false) {
  const split = Math.max(0,Math.min(100,Number(value)));
  range.value = String(split);
  const render = new CustomEvent('aeris:split-render', { cancelable: true, detail: { value: split, immediate } });
  comparison.dispatchEvent(render);
  if (!render.defaultPrevented) comparison.style.setProperty('--split',split+'%');
  range.setAttribute('aria-valuetext',`${Math.round(split)} percent before, ${100-Math.round(split)} percent after`);
}
range.addEventListener('input',() => setSplit(range.value));
comparison.addEventListener('aeris:hint-split', event => setSplit(event.detail, true));
let pointer = null;
let touchGesture = null;
function fromPointer(event) {
  const bounds = comparison.getBoundingClientRect();
  setSplit((event.clientX-bounds.left)/bounds.width*100);
}
range.addEventListener('pointerdown',event => {
  if(event.button !== 0) return;
  event.preventDefault();
  range.focus({preventScroll:true});
  pointer = event.pointerId;
  range.setPointerCapture(pointer);
  touchGesture = event.pointerType === 'touch' ? { x: event.clientX, y: event.clientY, axis: null } : null;
  if (!touchGesture) {
    comparison.classList.add('is-comparing'); fromPointer(event);
  }
});
range.addEventListener('pointermove',event => {
  if (event.pointerId !== pointer) return;
  if (touchGesture) {
    const dx = event.clientX - touchGesture.x, dy = event.clientY - touchGesture.y;
    if (!touchGesture.axis && Math.max(Math.abs(dx), Math.abs(dy)) > 8) {
      touchGesture.axis = Math.abs(dx) > Math.abs(dy) * 1.1 ? 'x' : 'y';
    }
    if (touchGesture.axis !== 'x') return;
    comparison.classList.add('is-comparing');
  }
  fromPointer(event);
});
function endPointer(event) {
  if(event.pointerId !== pointer) return;
  if (touchGesture && !touchGesture.axis && event.type === 'pointerup') fromPointer(event);
  touchGesture = null;
  pointer = null;
  comparison.classList.remove('is-comparing');
  if(range.hasPointerCapture(event.pointerId)) range.releasePointerCapture(event.pointerId);
}
for (const name of ['pointerup','pointercancel','lostpointercapture']) range.addEventListener(name,endPointer);

async function showCase(index) {
  const next = (index+cases.length)%cases.length;
  requested = next;
  const item = cases[next], revision = ++request;
  comparison.setAttribute('aria-busy','true');
  try {
    await loadCase(item);
  } catch {
    if (revision !== request) return;
    requested = current;
    comparison.removeAttribute('aria-busy');
    status.textContent = 'This case could not be loaded. Please try again.';
    return;
  }
  if(revision !== request) return;
  results.dispatchEvent(new CustomEvent('aeris:case-before-change'));
  current = next;
  copyBlocks[0].querySelector('h3').textContent = item.title;
  copyBlocks[0].querySelector('p').textContent = item.description;
  copyBlocks[1].querySelector('h3').textContent = item.concern;
  copyBlocks[1].querySelector('p').textContent = item.detail;
  applyImage(before,item.before,item.beforeAlt);
  applyImage(after,item.after,item.afterAlt);
  divider.src=item.divider; handle.src=item.handle;
  comparison.dataset.case=item.key;
  results.dataset.currentCase=String(current+1);
  comparison.setAttribute('aria-label',item.title+' — compare before and after');
  setSplit(50, true);
  status.textContent=item.title+', case '+(current+1)+' of '+cases.length;
  comparison.removeAttribute('aria-busy');
  results.dispatchEvent(new CustomEvent('aeris:case-change'));
  warmNextCase(current);
}
results.querySelector('[aria-label="Previous case"]').addEventListener('click',()=>showCase(requested-1));
results.querySelector('[aria-label="Next case"]').addEventListener('click',()=>showCase(requested+1));
results.dataset.currentCase='1';
comparison.dataset.case='veneers';
