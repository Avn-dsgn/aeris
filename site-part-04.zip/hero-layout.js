const hero = document.querySelector('.hero');
const family = hero.querySelector('.family');
const action = hero.querySelector('.hero-action');
let silhouette;
let frame;

// Sample the supplied transparent cutout once. Bounding-box intersection alone
// also counts its large transparent margins and adds unnecessary white panels.
function readSilhouette() {
  if (!family.naturalWidth) return;
  const canvas = document.createElement('canvas');
  canvas.width = 96;
  canvas.height = 72;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) return;
  context.drawImage(family, 0, 0, 96, 72);
  silhouette = context.getImageData(0, 0, 96, 72).data;
  schedule();
}

function fitDesktopComposition() {
  if (document.querySelector('.site').dataset.scaleLayout !== 'desktop') return;
  const words = hero.querySelectorAll('.hero-title > span');
  const audience = hero.querySelectorAll('.hero-audience > span');
  // Work in the unscaled artboard, independent of the entrance transforms.
  const height = family.offsetHeight;
  const pictureLeft = family.offsetLeft - family.offsetWidth / 2;
  const nurseLeft = pictureLeft + height * 558 / 1086;
  const motherRight = pictureLeft + height * 1144 / 1086;
  const wordLeft = Math.max(30, Math.min(82, nurseLeft - words[0].offsetWidth - 16));
  const wordRight = Math.max(30, Math.min(82, hero.clientWidth - motherRight - words[1].offsetWidth - 8));
  hero.style.setProperty('--desktop-hero-word-left', wordLeft + 'px');
  hero.style.setProperty('--desktop-hero-word-right', wordRight + 'px');
  hero.style.setProperty('--desktop-hero-adults-left', Math.max(30, wordLeft + words[0].offsetWidth - audience[0].offsetWidth) + 'px');
  hero.style.setProperty('--desktop-hero-children-left', Math.min(hero.clientWidth - audience[1].offsetWidth - 30, motherRight + 8) + 'px');
}

function fitBackdrop() {
  fitDesktopComposition();
  if (!silhouette) {
    action.classList.remove('over-photo');
    return;
  }
  const picture = family.getBoundingClientRect();
  const text = document.createRange();
  text.selectNodeContents(action.querySelector('p'));
  let overlaps = false;
  // Use the actual line lengths, excluding empty paragraph space and the
  // already opaque button, so neither creates an unnecessary backdrop.
  for (const copy of text.getClientRects()) {
    const x0 = Math.max(0, Math.floor((copy.left - 4 - picture.left) / picture.width * 96));
    const x1 = Math.min(95, Math.ceil((copy.right + 4 - picture.left) / picture.width * 96));
    const y0 = Math.max(0, Math.floor((copy.top - 4 - picture.top) / picture.height * 72));
    const y1 = Math.min(71, Math.ceil((copy.bottom + 4 - picture.top) / picture.height * 72));
    for (let y = y0; y <= y1 && !overlaps; y++) {
      for (let x = x0; x <= x1; x++) {
        if (silhouette[(y * 96 + x) * 4 + 3] > 64) {
          overlaps = true;
          break;
        }
      }
    }
    if (overlaps) break;
  }
  action.classList.toggle('over-photo', overlaps);
}

function schedule() {
  cancelAnimationFrame(frame);
  frame = requestAnimationFrame(fitBackdrop);
}

new ResizeObserver(schedule).observe(hero);
new ResizeObserver(schedule).observe(action);
window.addEventListener('resize', schedule);
document.fonts.ready.then(schedule);
family.addEventListener('load', readSilhouette);
if (family.complete) readSilhouette();

window.addEventListener('aeris:hero-settled', schedule);
