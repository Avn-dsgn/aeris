const toggle = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#main-navigation');
const compact = matchMedia('(max-width:767px), (max-width:1151px) and (max-height:500px) and (orientation:landscape)');

function closeMenu(returnFocus = false) {
  const wasOpen = toggle.getAttribute('aria-expanded') === 'true';
  if (!wasOpen) return;
  toggle.setAttribute('aria-expanded', 'false');
  toggle.querySelector('.menu-label').textContent = 'Menu';
  navigation.classList.remove('is-open');
  if (returnFocus && wasOpen) toggle.focus({ preventScroll: true });
}

toggle.addEventListener('click', () => {
  if (toggle.getAttribute('aria-expanded') === 'true') return closeMenu();
  toggle.setAttribute('aria-expanded', 'true');
  toggle.querySelector('.menu-label').textContent = 'Close';
  navigation.classList.add('is-open');
});
navigation.addEventListener('click', event => {
  if (event.target.closest('a')) closeMenu();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeMenu(true);
});
document.addEventListener('pointerdown', event => {
  if (!navigation.contains(event.target) && !toggle.contains(event.target)) closeMenu();
});
document.addEventListener('focusin', event => {
  if (compact.matches && !navigation.contains(event.target) && !toggle.contains(event.target)) closeMenu();
});
compact.addEventListener('change', () => closeMenu());
