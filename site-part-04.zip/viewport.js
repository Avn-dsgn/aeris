let previousWidth, previousFamily, phoneHeight;

// Browser toolbar/keyboard height changes must not resize a phone's content
// artboard mid-gesture. A width or layout-family change is a real reflow.
export function layoutViewportHeight() {
  const width = document.documentElement.clientWidth;
  const height = document.documentElement.clientHeight;
  const family = document.querySelector('.site').dataset.scaleLayout;
  if (!family?.startsWith('phone-')) {
    previousWidth = width; previousFamily = family; phoneHeight = undefined;
    return height;
  }
  if (width !== previousWidth || family !== previousFamily) {
    previousWidth = width; previousFamily = family; phoneHeight = height;
  }
  return phoneHeight;
}
