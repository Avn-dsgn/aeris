// The old equipment disappears completely before the new one enters. Animate
// existing layers only: no clones, per-click text splitting, or layout changes.
export function equipmentTransition(stage, { duration, finishEntry, reduced = false, compact = false }) {
  let outgoing, incoming, departure, arrivals = [], restoreOpacity, resolveTransition, generation = 0;
  const settle = () => {
    generation++;
    if (departure) departure.onfinish = null;
    departure?.cancel(); departure = null;
    arrivals.forEach(animation => animation.cancel()); arrivals = [];
    if (outgoing) {
      outgoing.hidden = true;
      outgoing.classList.remove('tech-transition-outgoing');
      outgoing.removeAttribute('aria-hidden'); outgoing.removeAttribute('inert');
      outgoing = null;
    }
    restoreOpacity?.(); restoreOpacity = null; incoming = null;
    resolveTransition?.(); resolveTransition = null;
  };
  const before = () => { finishEntry(); settle(); };
  const changed = event => {
    outgoing = event.detail.previous; incoming = event.detail.current;
    const revision = ++generation, target = incoming, previousOpacity = target.style.opacity;
    restoreOpacity = () => { target.style.opacity = previousOpacity; };
    target.style.opacity = '0';
    outgoing.classList.add('tech-transition-outgoing');
    outgoing.setAttribute('aria-hidden', 'true'); outgoing.setAttribute('inert', '');
    outgoing.hidden = false;
    stage.equipmentTransitionFinished = new Promise(resolve => { resolveTransition = resolve; });
    const exitDuration = Math.round(duration * .28), enterDuration = duration - exitDuration;
    departure = outgoing.animate([{ opacity: 1 }, { opacity: 0 }], {
      duration: exitDuration, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards',
    });
    departure.onfinish = () => {
      if (revision !== generation) return;
      outgoing.hidden = true;
      if (reduced) {
        arrivals = [target.animate([{ opacity: 0 }, { opacity: 1 }], { duration: enterDuration, fill: 'both' })];
      } else {
        const layers = [target.querySelector('.tech-equipment'), target.querySelector('.tech-title'),
          ...target.querySelectorAll('.tech-callout,.tech-benefit,.tech-line')].filter(Boolean);
        arrivals = layers.map((layer, index) => {
          const opacity = getComputedStyle(layer).opacity;
          const delay = Math.min(index * (compact ? 15 : 30), enterDuration * .18);
          return layer.animate([
            { opacity: 0, translate: `0 ${compact ? 6 : index === 0 ? 10 : 16}px` },
            { opacity, translate: '0 0' },
          ], { duration: enterDuration - delay, delay,
            easing: 'cubic-bezier(.22,1,.36,1)', fill: 'both' });
        });
        // All child from-states exist before revealing the incoming container.
        target.style.opacity = previousOpacity;
      }
      Promise.all(arrivals.map(animation => animation.finished)).then(() => {
        if (revision === generation) settle();
      }).catch(() => {}); // Cancellation on breakpoint change is intentional.
    };
  };
  stage.addEventListener('aeris:technology-before-change', before);
  stage.addEventListener('aeris:technology-change', changed);
  return () => {
    stage.removeEventListener('aeris:technology-before-change', before);
    stage.removeEventListener('aeris:technology-change', changed);
    settle(); delete stage.equipmentTransitionFinished;
  };
}
