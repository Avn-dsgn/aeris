import { motion } from './config.js';

export function headerMotion(gsap, conditions) {
  const hero = document.querySelector('.hero');
  const navigation = document.querySelector('.navigation');
  const parts = [...hero.querySelectorAll('.brand,.navigation,.menu-toggle,.contact-pill')];
  const links = [...navigation.querySelectorAll('a[href^="#"]')];
  const destinations = links.map(link => ({ link, section: document.getElementById(link.hash.slice(1)) })).filter(item => item.section);
  let frame = 0, lastY = window.scrollY, travelled = 0, lastDirection = 0, hidden = false, currentDestination;
  const show = value => {
    if (value === hidden) return;
    hidden = value;
    gsap.to(parts, { '--header-scroll-y': value ? motion.header.hideY : '0%', duration: motion.header.duration, ease: 'power3.out', overwrite: 'auto' });
  };
  const update = () => {
    frame = 0;
    const y = window.scrollY, delta = y - lastY;
    const direction = Math.sign(delta);
    travelled = direction === lastDirection ? travelled + Math.abs(delta) : Math.abs(delta);
    lastY = y; lastDirection = direction;
    let current;
    for (const item of destinations) if (item.section.getBoundingClientRect().top <= window.innerHeight * motion.header.activeLine) current = item;
    if (current !== currentDestination) {
      currentDestination?.link.removeAttribute('aria-current');
      current?.link.setAttribute('aria-current', 'location');
      currentDestination = current;
    }
    if (!conditions.desktop || conditions.reduced) return;
    const top = y < motion.header.topGuard;
    const focused = parts.some(part => part.contains(document.activeElement));
    const menuOpen = hero.querySelector('.menu-toggle').getAttribute('aria-expanded') === 'true';
    if (top || focused || menuOpen) show(false);
    else if (hero.getBoundingClientRect().bottom > 0 && travelled >= motion.header.directionThreshold) show(direction > 0);
  };
  const scroll = () => { if (!frame) frame = requestAnimationFrame(update); };
  const focus = event => { if (parts.some(part => part.contains(event.target))) show(false); };
  window.addEventListener('scroll', scroll, { passive: true });
  window.addEventListener('resize', scroll);
  hero.addEventListener('focusin', focus);
  update();
  return () => {
    cancelAnimationFrame(frame); window.removeEventListener('scroll', scroll); window.removeEventListener('resize', scroll); hero.removeEventListener('focusin', focus);
    gsap.killTweensOf(parts, '--header-scroll-y'); parts.forEach(part => part.style.removeProperty('--header-scroll-y'));
    links.forEach(link => link.removeAttribute('aria-current'));
  };
}
