import { motion } from '../config.js';
import { maskedHeading } from '../headings.js';
import { fadeUp, onceInView } from '../utils.js';
import { equipmentTransition } from '../equipment-transition.js';

export function technologyMotion(gsap, ScrollTrigger, SplitText, conditions) {
  const stage = document.querySelector('.technology-stage');
  const surface = stage.querySelector('.technology-fluid-surface');
  const slides = [...stage.querySelectorAll('.tech-slide')];
  let scope, heading, entryTween;
  const finishEntry = () => {
    entryTween?.progress(1);
    heading?.finish(); heading?.destroy(); heading = null;
    scope?.getTweens().forEach(tween => tween.progress(1));
    scope?.revert(); scope = null;
  };
  const stopEntry = onceInView(gsap, ScrollTrigger, stage, () => {
    const slide = slides[Number(stage.dataset.currentSlide || 1) - 1];
    entryTween = gsap.from(surface, { opacity: 0, duration: motion.duration.reveal,
      ease: motion.ease, clearProps: 'opacity' });
    scope = gsap.context(() => {
      gsap.from(slide, { opacity: 0, duration: conditions.reduced ? .16 : 1,
        ease: 'power2.out', clearProps: 'opacity' });
      if (!conditions.reduced) gsap.from(slide.querySelector('.tech-equipment'), {
        scale: 1.04, duration: 1.2, ease: motion.ease, clearProps: 'transform',
      });
      heading = maskedHeading(gsap, SplitText, slide.querySelector('.tech-title'), conditions, .08);
      // Each caption arrives as a unit. Its text is never masked a second time.
      slide.querySelectorAll('.tech-callout,.tech-benefit').forEach((card, index) => {
        fadeUp(gsap, card, conditions, .16 + index * .08);
      });
    }, slide);
  }, { prepare: [surface, ...slides], start: conditions.reduced ? motion.cards.start : motion.cards.showcaseStart });
  const stopTransitions = equipmentTransition(stage, {
    duration: conditions.reduced ? 120 : 800, reduced: conditions.reduced, finishEntry,
  });
  return () => { stopTransitions(); finishEntry(); stopEntry(); };
}
