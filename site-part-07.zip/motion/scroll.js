import { motion } from './config.js';

// Lenis writes the real window scroll position. No translated page wrapper or
// second RAF loop: fixed controls, native focus and ScrollTrigger share one clock.
export function smoothScroll(Lenis, gsap, ScrollTrigger) {
  const root = document.documentElement;
  const lenis = new Lenis({
    autoRaf: false, smoothWheel: true, syncTouch: false,
    lerp: motion.scroll.lerp, anchors: false, stopInertiaOnNavigate: true,
    virtualScroll: ({ deltaX, deltaY, event }) =>
      !event.defaultPrevented && !event.ctrlKey && Math.abs(deltaY) > Math.abs(deltaX),
    prevent: node => node.matches('dialog,[data-lenis-prevent]'),
  });
  const tick = time => lenis.raf(time * 1000);
  const cancel = () => lenis.reset();
  const sync = () => ScrollTrigger.update();
  const resize = () => lenis.resize();
  const key = event => {
    if (['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' ','Tab','Escape'].includes(event.key)) cancel();
  };
  const modal = () => {
    if (document.querySelector('dialog[open]')) lenis.stop();
    else lenis.start();
  };
  const observer = new MutationObserver(modal);
  document.querySelectorAll('dialog').forEach(dialog => observer.observe(dialog, { attributes: true, attributeFilter: ['open'] }));
  lenis.on('scroll', sync);
  // Consume wheel inertia before GSAP renders scroll-linked effects. Use real
  // elapsed time so a delayed frame cannot leave the scroll clock behind.
  gsap.ticker.lagSmoothing(0);
  gsap.ticker.add(tick, false, true);
  ScrollTrigger.addEventListener('refreshInit', cancel);
  ScrollTrigger.addEventListener('refresh', resize);
  window.addEventListener('pointerdown', cancel, { passive: true });
  window.addEventListener('touchstart', cancel, { passive: true });
  window.addEventListener('keydown', key);
  window.addEventListener('blur', cancel);
  document.addEventListener('visibilitychange', cancel);
  root.dataset.pageScroll = 'smooth';
  modal();
  return {
    scrollTo: (target, onComplete) => {
      cancel();
      lenis.scrollTo(target, { duration: motion.scroll.anchorDuration, lerp: 0, onComplete });
    },
    destroy() {
      observer.disconnect();
      window.removeEventListener('pointerdown', cancel);
      window.removeEventListener('touchstart', cancel);
      window.removeEventListener('keydown', key);
      window.removeEventListener('blur', cancel);
      document.removeEventListener('visibilitychange', cancel);
      ScrollTrigger.removeEventListener('refreshInit', cancel);
      ScrollTrigger.removeEventListener('refresh', resize);
      lenis.off('scroll', sync); gsap.ticker.remove(tick);
      cancel(); lenis.destroy(); delete root.dataset.pageScroll;
    },
  };
}
