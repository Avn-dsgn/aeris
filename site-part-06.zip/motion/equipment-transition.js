// A sequential dissolve: remove the old equipment before revealing the next.
// Reuse decoded slides; no DOM clones, line splitting or image movement on click.
export function equipmentTransition(stage, { duration, finishEntry }) {
  let outgoing, incoming, departure, arrival, restoreOpacity, resolveTransition;
  const settle = () => {
    departure?.cancel(); arrival?.cancel(); departure = arrival = null;
    if (outgoing) {
      outgoing.hidden = true;
      outgoing.classList.remove('tech-transition-outgoing');
      outgoing.removeAttribute('aria-hidden'); outgoing.removeAttribute('inert');
      outgoing = null;
    }
    restoreOpacity?.(); restoreOpacity = null; incoming = null;
    resolveTransition?.(); resolveTransition = null;
  };
  const before = () => { finishEntry(); settle(); };
  const changed = event => {
    outgoing = event.detail.previous; incoming = event.detail.current;
    const target = incoming, previousOpacity = target.style.opacity;
    restoreOpacity = () => { target.style.opacity = previousOpacity; };
    // Set the new slide's state synchronously, before the browser can paint it.
    target.style.opacity = '0';
    outgoing.classList.add('tech-transition-outgoing');
    outgoing.setAttribute('aria-hidden', 'true'); outgoing.setAttribute('inert', '');
    outgoing.hidden = false;
    stage.equipmentTransitionFinished = new Promise(resolve => { resolveTransition = resolve; });
    const exitDuration = Math.round(duration * .42);
    departure = outgoing.animate([{ opacity: 1 }, { opacity: 0 }], {
      duration: exitDuration, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards',
    });
    departure.onfinish = () => {
      outgoing.hidden = true;
      arrival = target.animate([{ opacity: 0 }, { opacity: 1 }], {
        duration: duration - exitDuration, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'forwards',
      });
      arrival.onfinish = settle;
    };
  };
  stage.addEventListener('aeris:technology-before-change', before);
  stage.addEventListener('aeris:technology-change', changed);
  return () => {
    stage.removeEventListener('aeris:technology-before-change', before);
    stage.removeEventListener('aeris:technology-change', changed);
    settle(); delete stage.equipmentTransitionFinished;
  };
}
