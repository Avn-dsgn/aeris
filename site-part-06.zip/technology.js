import { layoutViewportHeight } from './viewport.js';

const technology = document.querySelector('.technology-stage');

if (technology) {
  const slides = [...technology.querySelectorAll('.tech-slide')];
  const indicators = [...technology.querySelectorAll('.tech-indicators span')];
  const previous = technology.querySelector('[aria-label="Previous equipment"]');
  const next = technology.querySelector('[aria-label="Next equipment"]');
  const status = technology.querySelector('.tech-slide-status');
  let current = 0, requested = 0, requestId = 0;
  const decoded = new WeakMap();
  function preparePhoto(slide) {
    const image = slide.querySelector('.tech-equipment');
    if (!decoded.has(image)) {
      // decode() alone does not start a hidden lazy image in every browser.
      image.loading = 'eager';
      const artwork = [image, ...slide.querySelectorAll('img.tech-slide-glow,.tech-slide-glow img')];
      artwork.forEach(item => { item.loading = 'eager'; });
      decoded.set(image, Promise.all(artwork.map(item => item.decode())).then(() => true, () => false));
    }
    return decoded.get(image);
  }

  // Keep readable cards in flow and give the artwork the remaining window height.
  // Measuring hidden slides synchronously prevents a height jump on navigation.
  function fitScene() {
    const width = technology.clientWidth;
    const height = technology.clientHeight;
    if (!width || !height) return;
    const layoutScale = technology.getBoundingClientRect().width / technology.offsetWidth || 1;
    const viewportHeight = layoutViewportHeight();
    if (document.querySelector('.site').dataset.scaleLayout === 'desktop') {
      const label = document.querySelector('.technology > .section-label');
      const labelHeight = label.getBoundingClientRect().height / layoutScale +
        (Number.parseFloat(getComputedStyle(label).marginBottom) || 0);
      const available = Math.max(160, (viewportHeight - 48) / layoutScale - labelHeight);
      const sceneHeight = Math.min(available, width * 872 / 1580);
      const unit = Math.min(width / 1580, sceneHeight / 872);
      technology.style.setProperty('--desktop-technology-height', sceneHeight + 'px');
      technology.style.setProperty('--tech-unit', unit + 'px');
      technology.style.setProperty('--tech-origin', (width - 1580 * unit) / 2 + 'px');
      technology.classList.add('is-measuring');
      const captions = slides.flatMap(slide => [...slide.querySelectorAll('.tech-callout')]);
      const positions = captions.map(card => {
        const desired = Number.parseFloat(card.style.getPropertyValue('--y')) * unit;
        const cardHeight = card.getBoundingClientRect().height / layoutScale;
        return Math.max(0, Math.min(desired, sceneHeight - cardHeight - 20));
      });
      captions.forEach((card, index) => card.style.setProperty('--tech-caption-top', positions[index] + 'px'));
      technology.classList.remove('is-measuring');
      return;
    }
    const unit = width / 1580;
    technology.style.setProperty('--tech-unit', unit + 'px');
    technology.style.setProperty('--tech-origin', '0px');
    if (document.querySelector('.site').dataset.scaleLayout === 'phone-portrait' ||
        document.querySelector('.site').dataset.scaleLayout === 'phone-compact') {
      technology.classList.add('is-measuring');
      const detailsHeight = Math.max(...slides.map(slide =>
        slide.querySelector('.tech-details').getBoundingClientRect().height / layoutScale));
      technology.classList.remove('is-measuring');
      technology.style.setProperty('--phone-details-height', Math.ceil(detailsHeight) + 'px');
      return;
    }
    if (document.querySelector('.site').dataset.scaleLayout.startsWith('phone-landscape')) {
      technology.classList.add('is-measuring');
      const mainHeight = Math.max(width < 700 ? 360 : 420, ...slides.map(slide =>
        slide.querySelector('.tech-benefit').getBoundingClientRect().height / layoutScale + 96));
      technology.classList.remove('is-measuring');
      technology.style.setProperty('--landscape-main-height', Math.ceil(mainHeight) + 'px');
      return;
    }
    if (matchMedia('(max-width:1151px)').matches) {
      technology.classList.add('is-measuring');
      const detailsHeight = Math.max(...slides.map(slide =>
        slide.querySelector('.tech-details').getBoundingClientRect().height / layoutScale));
      technology.classList.remove('is-measuring');
      const visualHeight = Math.max(180, height - detailsHeight - 64);
      const artHeight = Math.min(width * 781 / 748, 960);
      technology.style.setProperty('--tablet-visual-height', visualHeight + 'px');
      technology.style.setProperty('--tablet-art-height', artHeight + 'px');
      const emphasis = document.querySelector('.site').dataset.scaleLayout === 'tablet-wide' ? 1.24 : 1;
      technology.style.setProperty('--tablet-art-scale', (visualHeight - 40) / artHeight * emphasis);
    }
  }
  let layoutFrame;
  const scheduleLayout = () => {
    cancelAnimationFrame(layoutFrame);
    layoutFrame = requestAnimationFrame(fitScene);
  };
  let viewportWidth = document.documentElement.clientWidth;
  let viewportHeight = layoutViewportHeight();
  let layoutFamily = document.querySelector('.site').dataset.scaleLayout;
  const resizeLayout = () => {
    const width = document.documentElement.clientWidth, height = layoutViewportHeight();
    const family = document.querySelector('.site').dataset.scaleLayout;
    if (width === viewportWidth && height === viewportHeight && family === layoutFamily) return;
    viewportWidth = width; viewportHeight = height; layoutFamily = family; scheduleLayout();
  };
  new ResizeObserver(scheduleLayout).observe(technology);
  window.addEventListener('resize', resizeLayout);
  document.fonts.ready.then(scheduleLayout);
  fitScene();

  async function showSlide(index) {
    const target = (index + slides.length) % slides.length;
    requested = target;
    const revision = ++requestId;
    if (target === current) return;
    // Keep the current frame visible until the next photograph is decoded.
    const ready = await preparePhoto(slides[target]);
    // Coalesce rapid input to the last requested slide without interrupting the
    // exit halfway through and exposing an unseen intermediate photograph.
    await technology.equipmentTransitionFinished;
    if (revision !== requestId || !ready) return;
    const detail = { previous: slides[current], current: slides[target] };
    technology.dispatchEvent(new CustomEvent('aeris:technology-before-change', { detail }));
    current = target;
    slides.forEach((slide, position) => { slide.hidden = position !== current; });
    indicators.forEach((indicator, position) => {
      indicator.classList.toggle('active', position === current);
    });
    const activeSlide = slides[current];
    technology.dataset.currentSlide = String(current + 1);
    status.textContent = activeSlide.querySelector('h3').textContent +
      ', slide ' + (current + 1) + ' of ' + slides.length;
    technology.dispatchEvent(new CustomEvent('aeris:technology-change', { detail }));
  }

  previous.addEventListener('click', () => showSlide(requested - 1));
  next.addEventListener('click', () => showSlide(requested + 1));
  for (const button of [previous, next]) {
    button.addEventListener('mousedown', event => {
      if (event.button !== 0) return;
      event.preventDefault();
      button.focus({ preventScroll: true });
    });
  }

  const hasTouchEvents = 'ontouchstart' in window;
  let gesture = null;
  technology.addEventListener('pointerdown', event => {
    if ((hasTouchEvents && event.pointerType === 'touch') || !event.isPrimary || event.button !== 0 ||
        event.target.closest('button,a,input,select,textarea')) return;
    gesture = { id: event.pointerId, x: event.clientX, y: event.clientY, dx: 0, active: false };
  });
  technology.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x;
    const dy = event.clientY - gesture.y;
    if (!gesture.active && Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      gesture.active = true;
      technology.setPointerCapture(event.pointerId);
      technology.classList.add('is-swiping');
    }
    if (!gesture.active) return;
    event.preventDefault();
    gesture.dx = dx;
    technology.style.setProperty('--tech-drag-offset', Math.max(-24, Math.min(24, dx * .12)) + 'px');
  }, { passive: false });
  function finishGesture(event, cancelled = false) {
    if (!gesture || event.pointerId !== gesture.id) return;
    const finished = gesture;
    if (!cancelled) finished.dx = event.clientX - finished.x;
    gesture = null;
    technology.classList.remove('is-swiping');
    technology.style.removeProperty('--tech-drag-offset');
    if (technology.hasPointerCapture(event.pointerId)) technology.releasePointerCapture(event.pointerId);
    if (!cancelled && finished.active && Math.abs(finished.dx) >= 48) {
      showSlide(requested + (finished.dx < 0 ? 1 : -1));
    }
  }
  technology.addEventListener('pointerup', event => finishGesture(event));
  technology.addEventListener('pointercancel', event => finishGesture(event, true));
  technology.addEventListener('lostpointercapture', event => finishGesture(event, true));

  // Touch has its own directional lock. The browser keeps vertical scrolling;
  // only a deliberate sideways gesture cancels native movement.
  let touchGesture = null;
  technology.addEventListener('touchstart', event => {
    if (event.touches.length !== 1 || event.target.closest('button,a,input,select,textarea')) {
      touchGesture = null;
      return;
    }
    const touch = event.touches[0];
    touchGesture = { id: touch.identifier, x: touch.clientX, y: touch.clientY, axis: null };
  }, { passive: true });
  technology.addEventListener('touchmove', event => {
    if (!touchGesture || event.touches.length !== 1) return;
    const touch = [...event.touches].find(item => item.identifier === touchGesture.id);
    if (!touch) return;
    const dx = touch.clientX - touchGesture.x;
    const dy = touch.clientY - touchGesture.y;
    if (!touchGesture.axis && Math.max(Math.abs(dx), Math.abs(dy)) > 8) {
      touchGesture.axis = Math.abs(dx) > Math.abs(dy) * 1.1 ? 'x' : 'y';
    }
    if (touchGesture.axis !== 'x') return;
    if (event.cancelable) event.preventDefault();
    technology.classList.add('is-swiping');
    technology.style.setProperty('--tech-drag-offset', Math.max(-24, Math.min(24, dx * .12)) + 'px');
  }, { passive: false });
  function finishTouch(event, cancelled = false) {
    const finished = touchGesture;
    touchGesture = null;
    technology.classList.remove('is-swiping');
    technology.style.removeProperty('--tech-drag-offset');
    if (!finished || cancelled) return;
    const touch = [...event.changedTouches].find(item => item.identifier === finished.id);
    if (!touch) return;
    const dx = touch.clientX - finished.x;
    const dy = touch.clientY - finished.y;
    if (finished.axis !== 'y' && Math.abs(dx) >= 32 && Math.abs(dx) > Math.abs(dy) * 1.1) {
      showSlide(requested + (dx < 0 ? 1 : -1));
    }
  }
  technology.addEventListener('touchend', event => finishTouch(event), { passive: true });
  technology.addEventListener('touchcancel', event => finishTouch(event, true), { passive: true });

  // One slide per horizontal trackpad gesture; vertical page scrolling stays native.
  let wheelTime = 0;
  let wheelDistance = 0;
  let wheelCommitted = false;
  technology.addEventListener('wheel', event => {
    if (event.ctrlKey) return;
    const horizontal = event.deltaX || (event.shiftKey ? event.deltaY : 0);
    if (!horizontal || (!event.shiftKey && Math.abs(horizontal) <= Math.abs(event.deltaY) * 1.1)) return;
    event.preventDefault();
    const now = performance.now();
    if (now - wheelTime > 180) {
      wheelDistance = 0;
      wheelCommitted = false;
    }
    wheelTime = now;
    if (wheelCommitted) return;
    const factor = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? technology.clientWidth : 1;
    wheelDistance += horizontal * factor;
    if (Math.abs(wheelDistance) >= 60) {
      wheelCommitted = true;
      showSlide(requested + Math.sign(wheelDistance));
    }
  }, { passive: false });
  technology.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === 'ArrowLeft') showSlide(requested - 1);
    if (event.key === 'ArrowRight') showSlide(requested + 1);
    if (event.key === 'Home') showSlide(0);
    if (event.key === 'End') showSlide(slides.length - 1);
  });

  // Warm the carousel near the viewport, away from Hero's critical downloads.
  const warmup = new IntersectionObserver(entries => {
    if (!entries.some(entry => entry.isIntersecting)) return;
    warmup.disconnect();
    slides.forEach(preparePhoto);
  }, { rootMargin: '800px 0px' });
  warmup.observe(technology);
  technology.dataset.currentSlide = '1';
}
